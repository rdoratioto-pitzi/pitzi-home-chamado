import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Package, 
  Truck, 
  Upload, 
  Search, 
  RefreshCw,
  X,
  Check,
  Clock,
  AlertCircle,
  FileSpreadsheet,
  ChevronDown,
  ChevronRight,
  Mail,
  MapPin,
  User,
  Phone,
  Building,
  Calendar,
  Loader2,
  RotateCcw,
  XCircle,
  Eye,
  Download,
  FileSearch,
  Filter,
  Plus,
  Trash2
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface MassaUploadRow {
  nome: string;
  cep: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cidade: string;
  uf: string;
  ddd?: string;
  telefone?: string;
  email?: string;
}

interface LogisticaReversaPedido {
  id: number;
  numeroPedido: string | null;
  numeroEtiqueta: string | null;
  tipo: string;
  codigoServico: string;
  status: string;
  idCliente: string | null;
  prazo: string | null;
  remetenteNome: string | null;
  remetenteCep: string | null;
  remetenteEndereco: string | null;
  remetenteCidade: string | null;
  remetenteUf: string | null;
  remetenteEmail: string | null;
  remetenteTelefone: string | null;
  destinatarioNome: string | null;
  destinatarioCep: string | null;
  destinatarioEndereco: string | null;
  destinatarioCidade: string | null;
  destinatarioUf: string | null;
  observacao: string | null;
  createdAt: string;
  eventos?: { id: number; status: string; descricao: string; dataEvento: string }[];
}

interface Servico {
  codigo: string;
  nome: string;
}

interface TipoColeta {
  codigo: string;
  nome: string;
}

interface Embalagem {
  codigo: string;
  nome: string;
  dimensoes: string;
  peso: number;
  codigoCorreios?: string;
}

interface ItemColeta {
  descricao: string;
  quantidade: number;
  valorUnitario: number;
  imei: string;
}

interface LRStats {
  total: number;
  pendentes: number;
  concluidos: number;
  cancelados: number;
}

const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  solicitado: { label: "Solicitado", className: "bg-blue-100 text-blue-800 border-blue-200" },
  aguardando_postagem: { label: "Aguardando Postagem", className: "bg-yellow-100 text-yellow-800 border-yellow-200" },
  coletado: { label: "Coletado", className: "bg-purple-100 text-purple-800 border-purple-200" },
  em_transito: { label: "Em Trânsito", className: "bg-indigo-100 text-indigo-800 border-indigo-200" },
  entregue: { label: "Entregue", className: "bg-green-100 text-green-800 border-green-200" },
  cancelado: { label: "Cancelado", className: "bg-red-100 text-red-800 border-red-200" },
  revalidado: { label: "Revalidado", className: "bg-teal-100 text-teal-800 border-teal-200" },
};

const TIPO_SERVICO_LABEL: Record<string, string> = {
  "41076": "PAC Reversa",
  "40010": "SEDEX Reversa",
  "40215": "SEDEX 10 Reversa",
  "40290": "SEDEX 12 Reversa",
};

const TIPO_COLETA_LABEL: Record<string, string> = {
  "A": "Autorização de Postagem",
  "C": "Coleta Domiciliar",
  "CA": "Coleta Simultânea",
};

export default function LogisticaReversaPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("solicitar");
  const [selectedPedido, setSelectedPedido] = useState<LogisticaReversaPedido | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [massaData, setMassaData] = useState<MassaUploadRow[]>([]);
  const [massaProgress, setMassaProgress] = useState(0);
  const [massaProcessing, setMassaProcessing] = useState(false);
  const [consultaNumero, setConsultaNumero] = useState("");
  const [consultaLoading, setConsultaLoading] = useState(false);
  const [filtroStatus, setFiltroStatus] = useState("todos");
  const [searchTerm, setSearchTerm] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: servicos } = useQuery<{ servicos: Servico[]; tipos: TipoColeta[]; embalagens: Embalagem[] }>({
    queryKey: ["/api/logistica-reversa/servicos"],
  });

  const { data: pedidos, isLoading: isLoadingPedidos } = useQuery<LogisticaReversaPedido[]>({
    queryKey: ["/api/logistica-reversa/pedidos"],
  });

  const { data: stats } = useQuery<LRStats>({
    queryKey: ["/api/logistica-reversa/stats"],
  });

  // Dados de teste pré-preenchidos para facilitar validação
  const dadosTeste = {
    remetente: {
      nome: "07 TIM MAIS CELULARES MACAÉ",
      logradouro: "Avenida Rui Barbosa",
      numero: "627",
      complemento: "",
      bairro: "Centro",
      cep: "27910361",
      cidade: "Macaé",
      uf: "RJ",
      ddd: "32",
      telefone: "988932850",
      email: "simonecontelecom@gmail.com",
    },
    itens: [
      { descricao: "SAMSUNG GALAXY A03 1 GB Black", quantidade: 1, valorUnitario: 450, imei: "350916874861670" },
      { descricao: "SAMSUNG GALAXY A71 1 GB", quantidade: 1, valorUnitario: 450, imei: "354909111096164" },
      { descricao: "APPLE iPhone 12 64 GB", quantidade: 1, valorUnitario: 450, imei: "357619533000804" },
      { descricao: "SAMSUNG GALAXY NOTE20 ULTRA 5G 128 GB", quantidade: 1, valorUnitario: 450, imei: "354149400545726" },
    ] as ItemColeta[],
  };

  const [formData, setFormData] = useState({
    tipo: "C",
    codigoServico: "41076",
    remetente: dadosTeste.remetente,
    destinatario: {
      nome: "RENOV SOLUCOES E SERVICOS LTDA",
      logradouro: "R LUIGI GALVANI",
      numero: "200",
      complemento: "CONJ 11",
      bairro: "CIDADE MONCOES",
      cep: "04575020",
      cidade: "SAO PAULO",
      uf: "SP",
      ddd: "51",
      telefone: "35438777",
      email: "MATHEUS@RENOVSMART.COM.BR",
    },
    observacao: "",
    itens: dadosTeste.itens,
    tipoEmbalagem: "P",
    adicionalArtigoPerigoso: true,
    valorDeclarado: 450,
  });

  const [cepLoading, setCepLoading] = useState(false);
  const [itensColapsado, setItensColapsado] = useState(false);
  const [itensFinalizado, setItensFinalizado] = useState(false);

  const solicitarMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/logistica-reversa/solicitar", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Solicitação enviada",
        description: `Pedido ${data.pedido?.numeroPedido || "criado"} com sucesso!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/pedidos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/stats"] });
      setFormData({
        ...formData,
        remetente: {
          nome: "",
          logradouro: "",
          numero: "",
          complemento: "",
          bairro: "",
          cep: "",
          cidade: "",
          uf: "",
          ddd: "",
          telefone: "",
          email: "",
        },
        observacao: "",
        itens: [],
        tipoEmbalagem: "",
        valorDeclarado: 0,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao solicitar",
        description: error.message || "Erro desconhecido",
        variant: "destructive",
      });
    },
  });

  const cancelarMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/logistica-reversa/cancelar/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Pedido cancelado com sucesso" });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/pedidos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/stats"] });
      setIsDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao cancelar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const revalidarMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/logistica-reversa/revalidar/${id}`);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Prazo revalidado",
        description: `Novo prazo: ${data.pedido?.prazo || "atualizado"}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/pedidos"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao revalidar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const atualizarStatusMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/logistica-reversa/atualizar-status/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Status atualizado com sucesso" });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/pedidos"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const solicitarMassaMutation = useMutation({
    mutationFn: async (data: { solicitacoes: any[]; destinatario: typeof formData.destinatario; codigoServico: string }) => {
      const response = await apiRequest("POST", "/api/logistica-reversa/solicitar-massa", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Solicitações enviadas",
        description: `${data.sucesso}/${data.total} pedidos criados com sucesso!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/pedidos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/stats"] });
      setMassaData([]);
      setMassaProgress(0);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao processar em massa",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSolicitar = (e: React.FormEvent) => {
    e.preventDefault();
    solicitarMutation.mutate(formData);
  };

  const parseCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let current = "";
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      const nextChar = line[i + 1];
      
      if (char === '"' && inQuotes && nextChar === '"') {
        current += '"';
        i++;
      } else if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const lines = content.split("\n").filter(l => l.trim());
        const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase().replace(/['"]/g, ''));
        
        const requiredHeaders = ['nome', 'cep', 'logradouro', 'cidade', 'uf', 'bairro'];
        const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
        
        if (missingHeaders.length > 0) {
          toast({
            title: "Cabeçalhos faltando",
            description: `Campos obrigatórios: ${missingHeaders.join(', ')}`,
            variant: "destructive",
          });
          return;
        }
        
        const rows: MassaUploadRow[] = [];
        const errors: string[] = [];
        
        for (let i = 1; i < lines.length && i <= 50; i++) {
          const values = parseCSVLine(lines[i]);
          const row: any = {};
          headers.forEach((h, idx) => {
            row[h] = values[idx]?.replace(/^['"]|['"]$/g, '') || "";
          });
          
          if (!row.nome || !row.cep || !row.logradouro || !row.cidade || !row.uf || !row.bairro) {
            errors.push(`Linha ${i + 1}: campos obrigatórios faltando`);
            continue;
          }
          
          const cepClean = row.cep.replace(/\D/g, '');
          if (cepClean.length !== 8) {
            errors.push(`Linha ${i + 1}: CEP inválido "${row.cep}"`);
            continue;
          }
          
          rows.push(row as MassaUploadRow);
        }
        
        setMassaData(rows);
        
        if (errors.length > 0 && rows.length > 0) {
          toast({
            title: `${rows.length} registros válidos carregados`,
            description: `${errors.length} linhas ignoradas por erros`,
          });
        } else if (rows.length > 0) {
          toast({
            title: "Arquivo carregado",
            description: `${rows.length} registros válidos encontrados`,
          });
        } else {
          toast({
            title: "Nenhum registro válido",
            description: errors.slice(0, 3).join("; "),
            variant: "destructive",
          });
        }
      } catch (err) {
        toast({
          title: "Erro ao processar arquivo",
          description: "Verifique se o formato está correto (CSV com cabeçalhos)",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
  };

  const handleProcessarMassa = async () => {
    if (massaData.length === 0) return;
    
    setMassaProcessing(true);
    setMassaProgress(0);
    
    const solicitacoes = massaData.map((row) => ({
      tipo: "A",
      remetente: {
        nome: row.nome,
        logradouro: row.logradouro,
        numero: row.numero,
        complemento: row.complemento || "",
        bairro: row.bairro,
        cep: row.cep.replace(/\D/g, ""),
        cidade: row.cidade,
        uf: row.uf,
        ddd: row.ddd || "",
        telefone: row.telefone || "",
        email: row.email || "",
      },
    }));

    try {
      await solicitarMassaMutation.mutateAsync({
        solicitacoes,
        destinatario: formData.destinatario,
        codigoServico: formData.codigoServico,
      });
    } finally {
      setMassaProcessing(false);
      setMassaProgress(100);
    }
  };

  const downloadModeloXlsx = () => {
    const a = document.createElement("a");
    a.href = "/api/logistica-reversa/modelo-xlsx";
    a.download = "modelo_coleta_reversa.xlsx";
    a.click();
  };

  const filteredPedidos = pedidos?.filter((p) => {
    const matchStatus = filtroStatus === "todos" || p.status === filtroStatus;
    const matchSearch = !searchTerm || 
      p.numeroPedido?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.remetenteNome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.idCliente?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchStatus && matchSearch;
  });

  const updateRemetente = (field: string, value: string) => {
    setFormData({
      ...formData,
      remetente: { ...formData.remetente, [field]: value },
    });
  };

  const consultarCep = async (cep: string) => {
    const cepLimpo = cep.replace(/\D/g, "");
    if (cepLimpo.length !== 8) return;
    
    setCepLoading(true);
    try {
      const response = await fetch(`/api/cep/${cepLimpo}`);
      if (response.ok) {
        const data = await response.json();
        setFormData({
          ...formData,
          remetente: {
            ...formData.remetente,
            cep: cep,
            logradouro: data.logradouro || formData.remetente.logradouro,
            bairro: data.bairro || formData.remetente.bairro,
            cidade: data.cidade || formData.remetente.cidade,
            uf: data.uf || formData.remetente.uf,
            ddd: data.ddd || formData.remetente.ddd,
          },
        });
        toast({
          title: "CEP encontrado",
          description: `${data.logradouro}, ${data.bairro} - ${data.cidade}/${data.uf}`,
        });
      }
    } catch (e) {
      toast({
        title: "Erro ao consultar CEP",
        variant: "destructive",
      });
    } finally {
      setCepLoading(false);
    }
  };

  const addItem = () => {
    setFormData({
      ...formData,
      itens: [...formData.itens, { descricao: "", quantidade: 1, valorUnitario: 0, imei: "" }],
    });
    setItensFinalizado(false);
    setItensColapsado(false);
  };

  const removeItem = (index: number) => {
    setFormData({
      ...formData,
      itens: formData.itens.filter((_, i) => i !== index),
    });
  };

  const [inputValue, setInputValue] = useState<Record<number, string>>({});

  const updateItem = (index: number, field: keyof ItemColeta, value: string | number) => {
    const newItens = [...formData.itens];
    newItens[index] = { ...newItens[index], [field]: value };
    setFormData({ ...formData, itens: newItens });
  };

  const valorTotalItens = formData.itens.reduce(
    (acc, item) => acc + (item.quantidade * item.valorUnitario),
    0
  );

  const finalizarItens = () => {
    if (formData.itens.length === 0) return;
    if (itensFinalizado) return;
    
    const itensTexto = formData.itens
      .filter(item => item.descricao.trim())
      .map(item => {
        const imeiPart = item.imei?.trim() ? ` - IMEI: ${item.imei.trim()}` : "";
        const qtdPart = item.quantidade > 1 ? ` (${item.quantidade}x)` : "";
        return `${item.descricao.trim()}${qtdPart}${imeiPart}`;
      })
      .join("; ");
    
    const observacaoLimpa = formData.observacao.replace(/\n*ITENS:[\s\S]*$/, "").trim();
    const novaObservacao = observacaoLimpa 
      ? `${observacaoLimpa}\n\nITENS: ${itensTexto}`
      : `ITENS: ${itensTexto}`;
    
    setFormData({ ...formData, observacao: novaObservacao });
    setItensFinalizado(true);
    setItensColapsado(true);
    
    toast({
      title: "Itens finalizados",
      description: "As informações dos itens foram adicionadas às observações.",
    });
  };

  const handleItemKeyDown = (e: React.KeyboardEvent, index: number, field: string) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const isLastItem = index === formData.itens.length - 1;
      const currentItem = formData.itens[index];
      const hasContent = currentItem.descricao.trim() || currentItem.imei?.trim();
      
      if (isLastItem && hasContent && (field === "imei" || field === "valorUnitario")) {
        addItem();
      }
    }
  };

  const formatarValorBRL = (valor: number): string => {
    return valor.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const parseValorBRL = (valor: string): number => {
    const apenasNumeros = valor.replace(/\D/g, "");
    if (!apenasNumeros) return 0;
    return parseInt(apenasNumeros) / 100;
  };

  const custoEstimadoColeta = () => {
    const totalDispositivos = formData.itens.reduce((acc, item) => acc + item.quantidade, 0);
    const pesoDispositivosKg = (totalDispositivos * 200) / 1000;
    const embalagem = servicos?.embalagens?.find(e => e.codigo === formData.tipoEmbalagem);
    const pesoEmbalagemKg = embalagem?.peso || 0;
    const pesoTotalKg = pesoDispositivosKg + pesoEmbalagemKg;
    const faixaPeso = Math.ceil(pesoTotalKg);
    
    const tabelaCorreios: Record<string, Record<number, number>> = {
      "41076": { 1: 18.90, 2: 22.50, 3: 26.10, 4: 29.70, 5: 33.30, 10: 51.50, 15: 69.70, 20: 87.90, 30: 124.30 },
      "40010": { 1: 32.90, 2: 38.50, 3: 44.10, 4: 49.70, 5: 55.30, 10: 83.30, 15: 111.30, 20: 139.30, 30: 195.30 },
      "40215": { 1: 65.90, 2: 75.50, 3: 85.10, 4: 94.70, 5: 104.30, 10: 152.30, 15: 200.30, 20: 248.30, 30: 344.30 },
      "40290": { 1: 48.90, 2: 56.50, 3: 64.10, 4: 71.70, 5: 79.30, 10: 117.30, 15: 155.30, 20: 193.30, 30: 269.30 },
    };
    
    const tabelaServico = tabelaCorreios[formData.codigoServico] || tabelaCorreios["41076"];
    const faixas = Object.keys(tabelaServico).map(Number).sort((a, b) => a - b);
    const faixaAplicavel = faixas.find(f => faixaPeso <= f) || faixas[faixas.length - 1];
    const custoFrete = tabelaServico[faixaAplicavel] || 18.90;
    
    const adicionalANAC = formData.adicionalArtigoPerigoso ? 5.00 : 0;
    
    return custoFrete + adicionalANAC;
  };

  return (
    <div className="p-6 space-y-6" data-testid="page-logistica-reversa">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900" data-testid="text-page-title">
            Logística Reversa
          </h1>
          <p className="text-sm text-slate-500">
            Solicite coletas, acompanhe pedidos e gerencie devoluções via Correios
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Total de Pedidos</p>
                <p className="text-2xl font-bold" data-testid="stat-total">{stats?.total || 0}</p>
              </div>
              <Package className="h-8 w-8 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-600" data-testid="stat-pendentes">{stats?.pendentes || 0}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Concluídos</p>
                <p className="text-2xl font-bold text-green-600" data-testid="stat-concluidos">{stats?.concluidos || 0}</p>
              </div>
              <Check className="h-8 w-8 text-green-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Cancelados</p>
                <p className="text-2xl font-bold text-red-600" data-testid="stat-cancelados">{stats?.cancelados || 0}</p>
              </div>
              <X className="h-8 w-8 text-red-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-flex">
          <TabsTrigger value="solicitar" data-testid="tab-solicitar">
            <Package className="h-4 w-4 mr-2" />
            Solicitar Coleta
          </TabsTrigger>
          <TabsTrigger value="massa" data-testid="tab-massa">
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Coleta em Massa
          </TabsTrigger>
          <TabsTrigger value="acompanhamento" data-testid="tab-acompanhamento">
            <Search className="h-4 w-4 mr-2" />
            Acompanhamento
          </TabsTrigger>
          <TabsTrigger value="consultas" data-testid="tab-consultas">
            <FileSearch className="h-4 w-4 mr-2" />
            Consultas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="solicitar" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="h-5 w-5" />
                Nova Solicitação de Coleta
              </CardTitle>
              <CardDescription>
                Solicite uma coleta reversa via Correios. O cliente poderá postar o pacote em uma agência ou 
                agendar coleta domiciliar.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSolicitar} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tipo">Tipo de Coleta</Label>
                    <Select
                      value={formData.tipo}
                      onValueChange={(v) => setFormData({ ...formData, tipo: v })}
                    >
                      <SelectTrigger data-testid="select-tipo">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        {servicos?.tipos.map((t) => (
                          <SelectItem key={t.codigo} value={t.codigo}>
                            {t.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="servico">Serviço</Label>
                    <Select
                      value={formData.codigoServico}
                      onValueChange={(v) => setFormData({ ...formData, codigoServico: v })}
                    >
                      <SelectTrigger data-testid="select-servico">
                        <SelectValue placeholder="Selecione o serviço" />
                      </SelectTrigger>
                      <SelectContent>
                        {servicos?.servicos.map((s) => (
                          <SelectItem key={s.codigo} value={s.codigo}>
                            {s.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold flex items-center gap-2 text-slate-700">
                    <User className="h-4 w-4" />
                    Dados do Remetente (Cliente que enviará)
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="rem-nome">Nome Completo *</Label>
                      <Input
                        id="rem-nome"
                        data-testid="input-remetente-nome"
                        value={formData.remetente.nome}
                        onChange={(e) => updateRemetente("nome", e.target.value)}
                        placeholder="Nome do remetente"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rem-email">E-mail <span className="text-xs text-slate-500">(para múltiplos, separe por vírgula)</span></Label>
                      <Input
                        id="rem-email"
                        data-testid="input-remetente-email"
                        type="text"
                        value={formData.remetente.email}
                        onChange={(e) => updateRemetente("email", e.target.value)}
                        placeholder="email@exemplo.com, outro@exemplo.com"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="rem-cep">CEP *</Label>
                      <div className="flex gap-2">
                        <Input
                          id="rem-cep"
                          data-testid="input-remetente-cep"
                          value={formData.remetente.cep}
                          onChange={(e) => updateRemetente("cep", e.target.value)}
                          onBlur={(e) => consultarCep(e.target.value)}
                          placeholder="00000-000"
                          maxLength={9}
                          required
                        />
                        <Button
                          type="button"
                          size="icon"
                          variant="outline"
                          disabled={cepLoading || formData.remetente.cep.replace(/\D/g, "").length !== 8}
                          onClick={() => consultarCep(formData.remetente.cep)}
                          data-testid="button-consultar-cep"
                        >
                          {cepLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2 col-span-2">
                      <Label htmlFor="rem-logradouro">Logradouro *</Label>
                      <Input
                        id="rem-logradouro"
                        data-testid="input-remetente-logradouro"
                        value={formData.remetente.logradouro}
                        onChange={(e) => updateRemetente("logradouro", e.target.value)}
                        placeholder="Rua, Avenida..."
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rem-numero">Número *</Label>
                      <Input
                        id="rem-numero"
                        data-testid="input-remetente-numero"
                        value={formData.remetente.numero}
                        onChange={(e) => updateRemetente("numero", e.target.value)}
                        placeholder="123"
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="rem-complemento">Complemento</Label>
                      <Input
                        id="rem-complemento"
                        data-testid="input-remetente-complemento"
                        value={formData.remetente.complemento}
                        onChange={(e) => updateRemetente("complemento", e.target.value)}
                        placeholder="Apto, Bloco..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rem-bairro">Bairro *</Label>
                      <Input
                        id="rem-bairro"
                        data-testid="input-remetente-bairro"
                        value={formData.remetente.bairro}
                        onChange={(e) => updateRemetente("bairro", e.target.value)}
                        placeholder="Bairro"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rem-cidade">Cidade *</Label>
                      <Input
                        id="rem-cidade"
                        data-testid="input-remetente-cidade"
                        value={formData.remetente.cidade}
                        onChange={(e) => updateRemetente("cidade", e.target.value)}
                        placeholder="Cidade"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rem-uf">UF *</Label>
                      <Input
                        id="rem-uf"
                        data-testid="input-remetente-uf"
                        value={formData.remetente.uf}
                        onChange={(e) => updateRemetente("uf", e.target.value.toUpperCase())}
                        placeholder="SP"
                        maxLength={2}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="rem-ddd">DDD</Label>
                      <Input
                        id="rem-ddd"
                        data-testid="input-remetente-ddd"
                        value={formData.remetente.ddd}
                        onChange={(e) => updateRemetente("ddd", e.target.value)}
                        placeholder="11"
                        maxLength={2}
                      />
                    </div>
                    <div className="space-y-2 col-span-3">
                      <Label htmlFor="rem-telefone">Telefone</Label>
                      <Input
                        id="rem-telefone"
                        data-testid="input-remetente-telefone"
                        value={formData.remetente.telefone}
                        onChange={(e) => updateRemetente("telefone", e.target.value)}
                        placeholder="999999999"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold flex items-center gap-2 text-slate-700">
                    <Building className="h-4 w-4" />
                    Dados do Destinatário (Onde será entregue)
                  </h3>
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Destino Padrão</AlertTitle>
                    <AlertDescription>
                      O destinatário está configurado como RENOV SOLUCOES E SERVICOS LTDA. 
                      Todos os pacotes serão enviados para este endereço.
                    </AlertDescription>
                  </Alert>
                  <div className="bg-slate-50 p-4 rounded-lg border">
                    <p className="font-medium">{formData.destinatario.nome}</p>
                    <p className="text-sm text-slate-600">
                      {formData.destinatario.logradouro}, {formData.destinatario.numero}
                      {formData.destinatario.complemento ? ` - ${formData.destinatario.complemento}` : ""}
                    </p>
                    <p className="text-sm text-slate-600">
                      {formData.destinatario.bairro} - {formData.destinatario.cidade}/{formData.destinatario.uf}
                    </p>
                    <p className="text-sm text-slate-600">CEP: {formData.destinatario.cep}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="observacao">Observações</Label>
                  <Textarea
                    id="observacao"
                    data-testid="input-observacao"
                    value={formData.observacao}
                    onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
                    placeholder="Informações adicionais sobre a coleta..."
                    rows={3}
                  />
                </div>

                <div className="border-t pt-4 space-y-4">
                  <div 
                    className="flex items-center justify-between cursor-pointer"
                    onClick={() => formData.itens.length > 0 && setItensColapsado(!itensColapsado)}
                  >
                    <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                      {formData.itens.length > 0 && (
                        itensColapsado ? <ChevronRight className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                      )}
                      <Package className="h-4 w-4" />
                      Itens a Coletar
                      {itensFinalizado && (
                        <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
                          <Check className="h-3 w-3 mr-1" />
                          Finalizado ({formData.itens.length} {formData.itens.length === 1 ? "item" : "itens"})
                        </Badge>
                      )}
                    </h3>
                    <div className="flex gap-2">
                      {formData.itens.length > 0 && !itensFinalizado && (
                        <Button 
                          type="button" 
                          variant="default" 
                          size="sm" 
                          onClick={(e) => { e.stopPropagation(); finalizarItens(); }}
                          data-testid="button-finalizar-itens"
                        >
                          <Check className="h-4 w-4 mr-1" />
                          Finalizar Itens
                        </Button>
                      )}
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        onClick={(e) => { e.stopPropagation(); addItem(); }}
                        data-testid="button-add-item"
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Adicionar Item
                      </Button>
                    </div>
                  </div>
                  
                  {formData.itens.length === 0 ? (
                    <p className="text-sm text-slate-500 text-center py-4 border rounded-lg border-dashed">
                      Clique em "Adicionar Item" para incluir dispositivos na coleta
                    </p>
                  ) : !itensColapsado && (
                    <div className="space-y-3">
                      {formData.itens.map((item, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 items-end p-3 bg-slate-50 rounded-lg">
                          <div className="col-span-4 space-y-1">
                            <Label className="text-xs">Descrição do Item</Label>
                            <Input
                              value={item.descricao}
                              onChange={(e) => updateItem(index, "descricao", e.target.value)}
                              onKeyDown={(e) => handleItemKeyDown(e, index, "descricao")}
                              placeholder="Ex: Celular Samsung Galaxy..."
                              data-testid={`input-item-descricao-${index}`}
                            />
                          </div>
                          <div className="col-span-1 space-y-1">
                            <Label className="text-xs">Qtd</Label>
                            <Input
                              type="number"
                              min={1}
                              value={item.quantidade}
                              onChange={(e) => updateItem(index, "quantidade", parseInt(e.target.value) || 1)}
                              onKeyDown={(e) => handleItemKeyDown(e, index, "quantidade")}
                              data-testid={`input-item-quantidade-${index}`}
                            />
                          </div>
                          <div className="col-span-2 space-y-1">
                            <Label className="text-xs">Valor Unit. (R$)</Label>
                            <Input
                              type="text"
                              value={inputValue[index] !== undefined ? inputValue[index] : formatarValorBRL(item.valorUnitario)}
                              onChange={(e) => {
                                let val = e.target.value.replace(/\D/g, "");
                                if (val.length > 0) {
                                  const integerPart = val.slice(0, -2) || "0";
                                  const decimalPart = val.slice(-2).padStart(2, "0");
                                  val = `${parseInt(integerPart).toLocaleString("pt-BR")},${decimalPart}`;
                                } else {
                                  val = "0,00";
                                }
                                setInputValue(prev => ({ ...prev, [index]: val }));
                                updateItem(index, "valorUnitario", parseValorBRL(val));
                              }}
                              onBlur={() => {
                                setInputValue(prev => {
                                  const next = { ...prev };
                                  delete next[index];
                                  return next;
                                });
                                // Ao sair do campo, garantimos que o valor do item está formatado corretamente
                                updateItem(index, "valorUnitario", parseValorBRL(inputValue[index] || formatarValorBRL(item.valorUnitario)));
                              }}
                              onKeyDown={(e) => handleItemKeyDown(e, index, "valorUnitario")}
                              placeholder="0,00"
                              data-testid={`input-item-valor-${index}`}
                            />
                          </div>
                          <div className="col-span-3 space-y-1">
                            <Label className="text-xs">IMEI</Label>
                            <Input
                              value={item.imei || ""}
                              onChange={(e) => updateItem(index, "imei", e.target.value)}
                              onKeyDown={(e) => handleItemKeyDown(e, index, "imei")}
                              placeholder="Ex: 351234567890123"
                              maxLength={20}
                              data-testid={`input-item-imei-${index}`}
                            />
                          </div>
                          <div className="col-span-2 flex justify-end">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => removeItem(index)}
                              data-testid={`button-remove-item-${index}`}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-slate-500">
                          Pressione Enter para adicionar novo item rapidamente
                        </p>
                        <p className="text-sm font-medium">
                          Valor Total dos Itens: <span className="text-primary">R$ {formatarValorBRL(valorTotalItens)}</span>
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="border-t pt-4 space-y-4">
                  <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                    <Package className="h-4 w-4" />
                    Embalagem e Adicionais
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="embalagem">Tipo de Embalagem</Label>
                      <Select
                        value={formData.tipoEmbalagem}
                        onValueChange={(value) => setFormData({ ...formData, tipoEmbalagem: value })}
                      >
                        <SelectTrigger id="embalagem" data-testid="select-embalagem">
                          <SelectValue placeholder="Selecione a embalagem..." />
                        </SelectTrigger>
                        <SelectContent>
                          {servicos?.embalagens?.map((emb) => (
                            <SelectItem key={emb.codigo} value={emb.codigo}>
                              {emb.nome} ({emb.dimensoes})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="valor-declarado">Valor Declarado (R$)</Label>
                      <Input
                        id="valor-declarado"
                        type="text"
                        value={formatarValorBRL(formData.valorDeclarado || valorTotalItens)}
                        onChange={(e) => setFormData({ ...formData, valorDeclarado: parseValorBRL(e.target.value) })}
                        placeholder="0,00"
                        data-testid="input-valor-declarado"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <Checkbox
                      id="adicional-anac"
                      checked={formData.adicionalArtigoPerigoso}
                      onCheckedChange={(checked) => setFormData({ ...formData, adicionalArtigoPerigoso: checked === true })}
                      data-testid="checkbox-adicional-anac"
                    />
                    <div className="flex-1">
                      <Label htmlFor="adicional-anac" className="font-medium text-amber-800 cursor-pointer">
                        Adicional 095 - ARTIGOS PERIGOSOS ANAC
                      </Label>
                      <p className="text-xs text-amber-600">
                        Marque esta opção para dispositivos com baterias de lítio (celulares, notebooks, tablets)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="bg-primary/10 p-4 rounded-lg mb-4">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-slate-700">Custo Estimado da Coleta:</span>
                      <span className="text-2xl font-bold text-primary">R$ {custoEstimadoColeta().toFixed(2)}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      * Valor estimado baseado no serviço e embalagem selecionados. O valor final pode variar.
                    </p>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={solicitarMutation.isPending}
                  data-testid="button-solicitar"
                >
                  {solicitarMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Solicitando...
                    </>
                  ) : (
                    <>
                      <Truck className="h-4 w-4 mr-2" />
                      Solicitar Coleta
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="massa" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                Coleta em Massa
              </CardTitle>
              <CardDescription>
                Faça upload de uma planilha Excel ou CSV com até 50 solicitações de coleta de uma vez.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Formato do Arquivo</AlertTitle>
                <AlertDescription>
                  A planilha deve conter as seguintes colunas: nome, cep, logradouro, numero, complemento, 
                  bairro, cidade, uf, ddd, telefone, email. Máximo de 50 linhas por arquivo.
                </AlertDescription>
              </Alert>

              <input
                type="file"
                ref={fileInputRef}
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
                data-testid="input-file-upload"
              />
              
              <div 
                className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-12 w-12 mx-auto text-slate-400 mb-4" />
                <p className="text-sm text-slate-600 mb-2">
                  Clique para selecionar um arquivo CSV
                </p>
                <Button variant="outline" type="button" data-testid="button-upload-file">
                  <Upload className="h-4 w-4 mr-2" />
                  Selecionar Arquivo
                </Button>
                <p className="text-xs text-slate-400 mt-4">
                  Formato aceito: .csv (máximo 50 registros)
                </p>
              </div>

              {massaData.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold">Preview ({massaData.length} registros)</h4>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setMassaData([])}
                      data-testid="button-limpar-preview"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Limpar
                    </Button>
                  </div>
                  <div className="rounded-md border max-h-60 overflow-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nome</TableHead>
                          <TableHead>CEP</TableHead>
                          <TableHead>Cidade/UF</TableHead>
                          <TableHead>Email</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {massaData.slice(0, 10).map((row, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{row.nome}</TableCell>
                            <TableCell>{row.cep}</TableCell>
                            <TableCell>{row.cidade}/{row.uf}</TableCell>
                            <TableCell>{row.email || "-"}</TableCell>
                          </TableRow>
                        ))}
                        {massaData.length > 10 && (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center text-slate-500">
                              ... e mais {massaData.length - 10} registros
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                  {massaProcessing && (
                    <div className="space-y-2">
                      <Progress value={massaProgress} className="h-2" />
                      <p className="text-sm text-center text-slate-500">Processando...</p>
                    </div>
                  )}
                </div>
              )}

              <div className="flex gap-4">
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={downloadModeloXlsx}
                  data-testid="button-download-modelo"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Baixar Modelo XLSX
                </Button>
                <Button 
                  className="flex-1" 
                  disabled={massaData.length === 0 || massaProcessing}
                  onClick={handleProcessarMassa}
                  data-testid="button-processar-massa"
                >
                  {massaProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <Truck className="h-4 w-4 mr-2" />
                      Processar {massaData.length > 0 ? `(${massaData.length})` : ""} Solicitações
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="acompanhamento" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Acompanhamento de Pedidos
              </CardTitle>
              <CardDescription>
                Visualize e gerencie todas as solicitações de logística reversa.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4 mb-4">
                <Input 
                  placeholder="Buscar por número do pedido ou cliente..." 
                  className="max-w-md"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  data-testid="input-buscar-pedido"
                />
                <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                  <SelectTrigger className="w-48" data-testid="select-filtro-status">
                    <SelectValue placeholder="Filtrar por status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os status</SelectItem>
                    <SelectItem value="solicitado">Solicitado</SelectItem>
                    <SelectItem value="aguardando_postagem">Aguardando Postagem</SelectItem>
                    <SelectItem value="em_transito">Em Trânsito</SelectItem>
                    <SelectItem value="entregue">Entregue</SelectItem>
                    <SelectItem value="cancelado">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
                <Button 
                  variant="outline"
                  onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/logistica-reversa/pedidos"] })}
                  data-testid="button-atualizar-lista"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Atualizar
                </Button>
              </div>

              {isLoadingPedidos ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredPedidos && filteredPedidos.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Pedido</TableHead>
                        <TableHead>Remetente</TableHead>
                        <TableHead>Serviço</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPedidos.map((pedido) => (
                        <TableRow key={pedido.id} data-testid={`row-pedido-${pedido.id}`}>
                          <TableCell className="font-medium">
                            {pedido.numeroPedido || pedido.idCliente || `#${pedido.id}`}
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{pedido.remetenteNome || "-"}</p>
                              <p className="text-xs text-slate-500">
                                {pedido.remetenteCidade}/{pedido.remetenteUf}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {TIPO_SERVICO_LABEL[pedido.codigoServico] || pedido.codigoServico}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={STATUS_CONFIG[pedido.status]?.className || "bg-slate-100"}>
                              {STATUS_CONFIG[pedido.status]?.label || pedido.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {new Date(pedido.createdAt).toLocaleDateString("pt-BR")}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex gap-1 justify-end">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setSelectedPedido(pedido);
                                  setIsDetailsOpen(true);
                                }}
                                data-testid={`button-ver-${pedido.id}`}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => atualizarStatusMutation.mutate(pedido.id)}
                                disabled={atualizarStatusMutation.isPending || pedido.status === "cancelado"}
                                data-testid={`button-atualizar-${pedido.id}`}
                              >
                                <RefreshCw className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => revalidarMutation.mutate(pedido.id)}
                                disabled={revalidarMutation.isPending || pedido.status === "cancelado"}
                                data-testid={`button-revalidar-${pedido.id}`}
                              >
                                <RotateCcw className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => cancelarMutation.mutate(pedido.id)}
                                disabled={cancelarMutation.isPending || pedido.status === "cancelado"}
                                className="text-red-500 hover:text-red-700"
                                data-testid={`button-cancelar-${pedido.id}`}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  <Package className="h-12 w-12 mx-auto mb-4 opacity-30" />
                  <p>Nenhum pedido de logística reversa encontrado</p>
                  <p className="text-sm">Crie uma nova solicitação na aba "Solicitar Coleta"</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="consultas" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSearch className="h-5 w-5" />
                Consulta de Pedido
              </CardTitle>
              <CardDescription>
                Consulte o status de um pedido específico pelo número de coleta ou etiqueta.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex gap-4">
                <Input
                  placeholder="Digite o número do pedido ou etiqueta..."
                  value={consultaNumero}
                  onChange={(e) => setConsultaNumero(e.target.value)}
                  className="max-w-md"
                  data-testid="input-consulta-numero"
                />
                <Button
                  disabled={!consultaNumero.trim() || consultaLoading}
                  onClick={async () => {
                    if (!consultaNumero.trim()) return;
                    setConsultaLoading(true);
                    try {
                      const response = await fetch(`/api/logistica-reversa/consulta/${encodeURIComponent(consultaNumero.trim())}`);
                      if (response.ok) {
                        const pedido = await response.json();
                        setSelectedPedido(pedido);
                        setIsDetailsOpen(true);
                      } else {
                        const localPedido = pedidos?.find(
                          p => p.numeroPedido === consultaNumero || 
                               p.numeroEtiqueta === consultaNumero ||
                               p.idCliente === consultaNumero
                        );
                        if (localPedido) {
                          setSelectedPedido(localPedido);
                          setIsDetailsOpen(true);
                        } else {
                          toast({
                            title: "Pedido não encontrado",
                            description: "Verifique o número informado",
                            variant: "destructive",
                          });
                        }
                      }
                    } catch (e) {
                      toast({
                        title: "Erro ao consultar",
                        description: "Tente novamente",
                        variant: "destructive",
                      });
                    } finally {
                      setConsultaLoading(false);
                    }
                  }}
                  data-testid="button-consultar"
                >
                  {consultaLoading ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Search className="h-4 w-4 mr-2" />
                  )}
                  Consultar
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      Por Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(STATUS_CONFIG).map(([key, config]) => {
                        const count = pedidos?.filter(p => p.status === key).length || 0;
                        return (
                          <div 
                            key={key} 
                            className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 cursor-pointer"
                            onClick={() => {
                              setFiltroStatus(key);
                              setActiveTab("acompanhamento");
                            }}
                          >
                            <Badge className={config.className}>{config.label}</Badge>
                            <span className="text-sm font-medium">{count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Resumo
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500">Total de Pedidos</span>
                        <span className="text-xl font-bold">{stats?.total || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500">Em Andamento</span>
                        <span className="text-xl font-bold text-yellow-600">{stats?.pendentes || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500">Concluídos</span>
                        <span className="text-xl font-bold text-green-600">{stats?.concluidos || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500">Taxa de Conclusão</span>
                        <span className="text-xl font-bold text-primary">
                          {stats?.total ? Math.round((stats.concluidos / stats.total) * 100) : 0}%
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Pedido</DialogTitle>
            <DialogDescription>
              Pedido #{selectedPedido?.numeroPedido || selectedPedido?.id}
            </DialogDescription>
          </DialogHeader>
          {selectedPedido && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-500">Status</p>
                  <Badge className={STATUS_CONFIG[selectedPedido.status]?.className || "bg-slate-100"}>
                    {STATUS_CONFIG[selectedPedido.status]?.label || selectedPedido.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Serviço</p>
                  <p className="font-medium">
                    {TIPO_SERVICO_LABEL[selectedPedido.codigoServico] || selectedPedido.codigoServico}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Tipo de Coleta</p>
                  <p className="font-medium">
                    {TIPO_COLETA_LABEL[selectedPedido.tipo] || selectedPedido.tipo}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Prazo</p>
                  <p className="font-medium">{selectedPedido.prazo || "-"}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Remetente
                </h4>
                <div className="bg-slate-50 p-3 rounded-lg">
                  <p className="font-medium">{selectedPedido.remetenteNome}</p>
                  <p className="text-sm text-slate-600">{selectedPedido.remetenteEndereco}</p>
                  <p className="text-sm text-slate-600">
                    {selectedPedido.remetenteCidade}/{selectedPedido.remetenteUf} - CEP: {selectedPedido.remetenteCep}
                  </p>
                  {selectedPedido.remetenteEmail && (
                    <p className="text-sm text-slate-600">{selectedPedido.remetenteEmail}</p>
                  )}
                </div>
              </div>

              {selectedPedido.eventos && selectedPedido.eventos.length > 0 && (
                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Histórico de Eventos
                  </h4>
                  <div className="space-y-2">
                    {selectedPedido.eventos.map((evento) => (
                      <div key={evento.id} className="flex gap-3 text-sm">
                        <span className="text-slate-400">
                          {new Date(evento.dataEvento).toLocaleString("pt-BR")}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {evento.status}
                        </Badge>
                        <span>{evento.descricao}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => atualizarStatusMutation.mutate(selectedPedido.id)}
                  disabled={atualizarStatusMutation.isPending || selectedPedido.status === "cancelado"}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Atualizar Status
                </Button>
                <Button
                  variant="outline"
                  onClick={() => revalidarMutation.mutate(selectedPedido.id)}
                  disabled={revalidarMutation.isPending || selectedPedido.status === "cancelado"}
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Revalidar Prazo
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => cancelarMutation.mutate(selectedPedido.id)}
                  disabled={cancelarMutation.isPending || selectedPedido.status === "cancelado"}
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Cancelar Pedido
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
