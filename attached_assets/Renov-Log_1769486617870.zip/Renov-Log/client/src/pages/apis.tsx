import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { 
  Code, 
  Truck, 
  Check, 
  X, 
  Clock, 
  ExternalLink,
  Copy,
  FileText,
  Zap,
  Shield,
  Search,
  Loader2,
  Package,
  MapPin,
  Calendar,
  AlertCircle,
  Mail
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Endpoint {
  method: "GET" | "POST" | "PUT" | "DELETE" | "PATCH";
  path: string;
  description: string;
  params?: { name: string; type: string; required: boolean; description: string }[];
  response?: string;
}

interface OperadorIntegracao {
  id: string;
  nome: string;
  status: "ativo" | "inativo" | "em_desenvolvimento";
  urlBase: string;
  documentacao?: string;
  ultimaAtualizacao: string;
  endpoints: Endpoint[];
}

const METHOD_COLORS: Record<string, string> = {
  GET: "bg-green-100 text-green-800",
  POST: "bg-blue-100 text-blue-800",
  PUT: "bg-yellow-100 text-yellow-800",
  DELETE: "bg-red-100 text-red-800",
  PATCH: "bg-purple-100 text-purple-800",
};

const STATUS_CONFIG = {
  ativo: { label: "Ativo", icon: Check, className: "bg-green-100 text-green-800 border-green-200" },
  inativo: { label: "Inativo", icon: X, className: "bg-red-100 text-red-800 border-red-200" },
  em_desenvolvimento: { label: "Em Desenvolvimento", icon: Clock, className: "bg-yellow-100 text-yellow-800 border-yellow-200" },
};

interface RastreioEvento {
  data: string;
  hora: string;
  local: string;
  status: string;
  detalhes?: string;
}

interface RastreioResult {
  codigo: string;
  servico: string;
  previsaoEntrega?: string;
  eventos: RastreioEvento[];
}

interface CorreiosStatus {
  configured: boolean;
  tokenValid: boolean;
  expiraEm?: string;
}

const internalEndpoints: Endpoint[] = [
  {
    method: "GET",
    path: "/api/auth/me",
    description: "Retorna dados do usuário autenticado",
    response: "{ id, name, email, role }",
  },
  {
    method: "POST",
    path: "/api/auth/login",
    description: "Autentica usuário no sistema",
    params: [
      { name: "email", type: "string", required: true, description: "Email do usuário" },
      { name: "password", type: "string", required: true, description: "Senha do usuário" },
    ],
  },
  {
    method: "POST",
    path: "/api/auth/logout",
    description: "Encerra a sessão do usuário",
  },
  {
    method: "GET",
    path: "/api/operators",
    description: "Lista todos os operadores logísticos",
    response: "[{ id, razaoSocial, cnpj, email, ativo }]",
  },
  {
    method: "POST",
    path: "/api/operators",
    description: "Cadastra novo operador logístico",
    params: [
      { name: "razaoSocial", type: "string", required: true, description: "Nome da empresa" },
      { name: "cnpj", type: "string", required: true, description: "CNPJ do operador" },
      { name: "email", type: "string", required: true, description: "Email de contato" },
    ],
  },
  {
    method: "GET",
    path: "/api/requests",
    description: "Lista solicitações de coleta",
    response: "[{ id, origem, destino, peso, status, valorEstimado }]",
  },
  {
    method: "POST",
    path: "/api/requests",
    description: "Cria nova solicitação de coleta",
    params: [
      { name: "origem", type: "string", required: true, description: "Cidade/UF de origem" },
      { name: "destino", type: "string", required: true, description: "Cidade/UF de destino" },
      { name: "peso", type: "number", required: true, description: "Peso em kg" },
      { name: "cubagem", type: "number", required: false, description: "Cubagem em m³" },
    ],
  },
  {
    method: "POST",
    path: "/api/simulation",
    description: "Simula cotação de frete entre operadores",
    params: [
      { name: "origem", type: "string", required: true, description: "Cidade/UF de origem" },
      { name: "destino", type: "string", required: true, description: "Cidade/UF de destino" },
      { name: "peso", type: "number", required: true, description: "Peso em kg" },
    ],
    response: "[{ operador, preco, prazo, score }]",
  },
  {
    method: "GET",
    path: "/api/dashboard/stats",
    description: "Retorna estatísticas do dashboard",
    response: "{ totalRequests, totalValue, onTimeRate, savings }",
  },
  {
    method: "GET",
    path: "/api/cte",
    description: "Lista CT-e emitidos",
    response: "[{ id, numero, chave, status, valorTotal }]",
  },
];

const operadoresIntegracao: OperadorIntegracao[] = [
  {
    id: "rapidcargo",
    nome: "RapidCargo Logística",
    status: "ativo",
    urlBase: "https://api.rapidcargo.com.br/v1",
    documentacao: "https://docs.rapidcargo.com.br",
    ultimaAtualizacao: "2026-01-15",
    endpoints: [
      { method: "GET", path: "/cotacao", description: "Consulta cotação de frete" },
      { method: "POST", path: "/coleta", description: "Agenda coleta" },
      { method: "GET", path: "/rastreio/{codigo}", description: "Rastreia remessa" },
      { method: "GET", path: "/cte/{numero}", description: "Consulta CT-e" },
    ],
  },
  {
    id: "transnacional",
    nome: "TransNacional Transportes",
    status: "ativo",
    urlBase: "https://api.transnacional.com.br/api",
    documentacao: "https://developer.transnacional.com.br",
    ultimaAtualizacao: "2026-01-10",
    endpoints: [
      { method: "POST", path: "/frete/calcular", description: "Calcula frete" },
      { method: "POST", path: "/pedido/criar", description: "Cria pedido de transporte" },
      { method: "GET", path: "/tracking/{awb}", description: "Tracking por AWB" },
    ],
  },
  {
    id: "expressbr",
    nome: "ExpressBR",
    status: "em_desenvolvimento",
    urlBase: "https://api.expressbr.com/v2",
    ultimaAtualizacao: "2026-01-05",
    endpoints: [
      { method: "GET", path: "/quote", description: "Cotação expressa" },
      { method: "POST", path: "/shipment", description: "Cria envio" },
    ],
  },
  {
    id: "logifast",
    nome: "LogiFast",
    status: "inativo",
    urlBase: "https://ws.logifast.com.br",
    ultimaAtualizacao: "2025-12-20",
    endpoints: [
      { method: "GET", path: "/preco", description: "Consulta preço" },
    ],
  },
];

export default function ApisPage() {
  const { toast } = useToast();
  const [codigoRastreio, setCodigoRastreio] = useState("");
  const [rastreioResult, setRastreioResult] = useState<RastreioResult | null>(null);

  const { data: correiosStatus } = useQuery<CorreiosStatus>({
    queryKey: ["/api/integrations/correios/status"],
  });

  const rastreioMutation = useMutation({
    mutationFn: async (codigo: string) => {
      const res = await fetch(`/api/integrations/correios/rastro/${codigo}`, {
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Erro ao rastrear objeto");
      }
      return data;
    },
    onSuccess: (data: RastreioResult) => {
      setRastreioResult(data);
      toast({ title: "Rastreamento encontrado!", description: `${data.eventos.length} evento(s) encontrado(s).` });
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao rastrear", description: error.message, variant: "destructive" });
      setRastreioResult(null);
    },
  });

  const handleRastrear = () => {
    if (!codigoRastreio.trim()) {
      toast({ title: "Código obrigatório", description: "Digite um código de rastreio válido.", variant: "destructive" });
      return;
    }
    rastreioMutation.mutate(codigoRastreio.trim());
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copiado!", description: "Endpoint copiado para a área de transferência." });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-slate-900">APIs Log</h2>
        <p className="text-slate-500 mt-2">Documentação interna de endpoints e integrações com operadores logísticos.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Endpoints Internos</CardTitle>
            <Code className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{internalEndpoints.length}</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Operadores Ativos</CardTitle>
            <Check className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {operadoresIntegracao.filter(o => o.status === "ativo").length}
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Em Desenvolvimento</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {operadoresIntegracao.filter(o => o.status === "em_desenvolvimento").length}
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total Integrações</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{operadoresIntegracao.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="correios" className="space-y-4">
        <TabsList>
          <TabsTrigger value="correios" data-testid="tab-correios">
            <Mail className="h-4 w-4 mr-2" />
            Correios
          </TabsTrigger>
          <TabsTrigger value="internal" data-testid="tab-internal-apis">
            <FileText className="h-4 w-4 mr-2" />
            APIs Internas
          </TabsTrigger>
          <TabsTrigger value="operators" data-testid="tab-operators-apis">
            <Truck className="h-4 w-4 mr-2" />
            Operadores Logísticos
          </TabsTrigger>
        </TabsList>

        <TabsContent value="correios" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-yellow-600" />
                    Rastreamento de Encomendas - Correios
                  </CardTitle>
                  <CardDescription>
                    Consulte o status de rastreamento de objetos via API oficial dos Correios
                  </CardDescription>
                </div>
                <Badge 
                  variant="outline" 
                  className={correiosStatus?.configured 
                    ? "bg-green-100 text-green-800 border-green-200" 
                    : "bg-yellow-100 text-yellow-800 border-yellow-200"
                  }
                >
                  {correiosStatus?.configured ? (
                    <><Check className="h-3 w-3 mr-1" /> Configurado</>
                  ) : (
                    <><AlertCircle className="h-3 w-3 mr-1" /> Aguardando Credenciais</>
                  )}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Digite o código de rastreio (ex: AA123456789BR)"
                    value={codigoRastreio}
                    onChange={(e) => setCodigoRastreio(e.target.value.toUpperCase())}
                    className="pl-10"
                    data-testid="input-codigo-rastreio"
                    onKeyDown={(e) => e.key === "Enter" && handleRastrear()}
                  />
                </div>
                <Button 
                  onClick={handleRastrear} 
                  disabled={rastreioMutation.isPending}
                  data-testid="button-rastrear"
                >
                  {rastreioMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Search className="h-4 w-4 mr-2" />
                  )}
                  Rastrear
                </Button>
              </div>

              {!correiosStatus?.configured && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-yellow-800">Credenciais não configuradas</p>
                      <p className="text-sm text-yellow-700 mt-1">
                        Para utilizar a API de rastreamento dos Correios, é necessário configurar as credenciais:
                      </p>
                      <ul className="text-sm text-yellow-700 mt-2 list-disc list-inside space-y-1">
                        <li>CORREIOS_API_KEY - Chave de Acesso CWS (gerar no portal Meu Correios)</li>
                      </ul>
                      <p className="text-xs text-yellow-600 mt-2">
                        Nota: Desde 2025, a API só permite rastrear objetos do próprio contrato.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {rastreioResult && (
                <div className="space-y-4">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="flex flex-wrap items-center gap-4">
                      <div>
                        <p className="text-xs text-slate-500 uppercase">Código</p>
                        <p className="font-mono font-bold">{rastreioResult.codigo}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase">Serviço</p>
                        <p className="font-medium">{rastreioResult.servico}</p>
                      </div>
                      {rastreioResult.previsaoEntrega && (
                        <div>
                          <p className="text-xs text-slate-500 uppercase">Previsão de Entrega</p>
                          <p className="font-medium">{rastreioResult.previsaoEntrega}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 uppercase mb-3">Histórico de Eventos</h4>
                    <div className="relative">
                      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-slate-200" />
                      <div className="space-y-4">
                        {rastreioResult.eventos.map((evento, index) => (
                          <div key={index} className="relative pl-10">
                            <div className="absolute left-2 w-4 h-4 rounded-full bg-blue-500 border-2 border-white shadow" />
                            <div className="bg-white border rounded-lg p-3 shadow-sm">
                              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-1">
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3" />
                                  {evento.data} às {evento.hora}
                                </span>
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {evento.local}
                                </span>
                              </div>
                              <p className="font-medium text-slate-800">{evento.status}</p>
                              {evento.detalhes && (
                                <p className="text-sm text-slate-500 mt-1">{evento.detalhes}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="border-t pt-4">
                <h4 className="font-semibold text-sm text-slate-500 uppercase mb-3">Endpoints Disponíveis</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Badge className="bg-green-100 text-green-800 text-xs">GET</Badge>
                    <code className="text-xs">/api/integrations/correios/rastro/:codigo</code>
                    <span className="text-xs text-slate-400">- Rastreia objeto por código</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Badge className="bg-green-100 text-green-800 text-xs">GET</Badge>
                    <code className="text-xs">/api/integrations/correios/status</code>
                    <span className="text-xs text-slate-400">- Verifica status da integração</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="internal" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Endpoints da API RenovLog
              </CardTitle>
              <CardDescription>
                Documentação dos endpoints internos da plataforma
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="multiple" className="w-full">
                {internalEndpoints.map((endpoint, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center gap-3">
                        <Badge className={METHOD_COLORS[endpoint.method]}>
                          {endpoint.method}
                        </Badge>
                        <code className="text-sm font-mono">{endpoint.path}</code>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pl-4 pt-2">
                        <p className="text-sm text-slate-600">{endpoint.description}</p>
                        
                        {endpoint.params && endpoint.params.length > 0 && (
                          <div>
                            <p className="text-xs font-semibold text-slate-500 uppercase mb-2">Parâmetros</p>
                            <div className="space-y-2">
                              {endpoint.params.map((param, pIndex) => (
                                <div key={pIndex} className="flex items-start gap-2 text-sm">
                                  <code className="bg-slate-100 px-2 py-0.5 rounded text-xs">{param.name}</code>
                                  <Badge variant="outline" className="text-xs">{param.type}</Badge>
                                  {param.required && <Badge className="bg-red-100 text-red-800 text-xs">obrigatório</Badge>}
                                  <span className="text-slate-500">{param.description}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {endpoint.response && (
                          <div>
                            <p className="text-xs font-semibold text-slate-500 uppercase mb-2">Resposta</p>
                            <code className="text-xs bg-slate-100 p-2 rounded block">{endpoint.response}</code>
                          </div>
                        )}

                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => copyToClipboard(endpoint.path)}
                        >
                          <Copy className="h-3 w-3 mr-2" />
                          Copiar Endpoint
                        </Button>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="operators" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {operadoresIntegracao.map((operador) => {
              const StatusIcon = STATUS_CONFIG[operador.status].icon;
              return (
                <Card key={operador.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Truck className="h-5 w-5 text-primary" />
                        {operador.nome}
                      </CardTitle>
                      <Badge variant="outline" className={STATUS_CONFIG[operador.status].className}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {STATUS_CONFIG[operador.status].label}
                      </Badge>
                    </div>
                    <CardDescription>
                      Última atualização: {operador.ultimaAtualizacao}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-xs font-semibold text-slate-500 uppercase mb-1">URL Base</p>
                      <code className="text-xs bg-slate-100 p-2 rounded block break-all">{operador.urlBase}</code>
                    </div>

                    <div>
                      <p className="text-xs font-semibold text-slate-500 uppercase mb-2">Endpoints Disponíveis</p>
                      <div className="space-y-2">
                        {operador.endpoints.map((ep, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <Badge className={`${METHOD_COLORS[ep.method]} text-xs`}>{ep.method}</Badge>
                            <code className="text-xs">{ep.path}</code>
                            <span className="text-xs text-slate-400">- {ep.description}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {operador.documentacao && (
                      <Button variant="outline" size="sm" className="w-full" asChild>
                        <a href={operador.documentacao} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Ver Documentação Completa
                        </a>
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
