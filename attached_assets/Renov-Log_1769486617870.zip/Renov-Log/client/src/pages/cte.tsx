import { useCtes } from "@/hooks/use-logistics";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText, Loader2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function CtePage() {
  const { data: ctes, isLoading } = useCtes();

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-slate-900">Emissões de CT-e</h2>
        <p className="text-slate-500 mt-2">Histórico de Conhecimentos de Transporte Eletrônicos emitidos.</p>
      </div>

      <div className="border rounded-xl bg-white shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-slate-50">
            <TableRow>
              <TableHead>Número CT-e</TableHead>
              <TableHead>Chave de Acesso</TableHead>
              <TableHead>Valor</TableHead>
              <TableHead>Status SEFAZ</TableHead>
              <TableHead>Data Emissão</TableHead>
              <TableHead className="text-right">XML</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" />
                </TableCell>
              </TableRow>
            ) : ctes?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  Nenhum CT-e emitido.
                </TableCell>
              </TableRow>
            ) : (
              ctes?.map((cte) => (
                <TableRow key={cte.id} className="hover:bg-slate-50/50">
                  <TableCell className="font-medium flex items-center gap-2">
                    <FileText className="h-4 w-4 text-blue-500" />
                    {cte.numeroCte || "-"}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-slate-500">
                    {cte.chaveAcesso || "Pendente de autorização"}
                  </TableCell>
                  <TableCell>
                    {cte.valor 
                      ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(cte.valor))
                      : "-"
                    }
                  </TableCell>
                  <TableCell>
                    <Badge variant={cte.statusSefaz === 'authorized' ? 'default' : 'secondary'} className={
                      cte.statusSefaz === 'authorized' ? 'bg-green-100 text-green-800 hover:bg-green-200' : ''
                    }>
                      {cte.statusSefaz}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-slate-500">
                    {cte.dataEmissao ? format(new Date(cte.dataEmissao), "dd/MM/yyyy HH:mm", { locale: ptBR }) : "-"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" disabled={!cte.xmlPath}>
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
