import { useState } from "react";
import { useSimulateRequest, useCreateRequest } from "@/hooks/use-logistics";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer 
} from "recharts";
import { Loader2, ArrowRight, CheckCircle2, Trophy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function SimulationPage() {
  const [formData, setFormData] = useState({
    origem: "São Paulo",
    destino: "Rio de Janeiro",
    peso: "10",
    cubagem: "0.5"
  });
  
  const { mutateAsync: simulate, isPending: isSimulating, data: results } = useSimulateRequest();
  const { mutateAsync: createRequest, isPending: isCreating } = useCreateRequest();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();

  const handleSimulate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await simulate({
        ...formData,
        peso: Number(formData.peso),
        cubagem: Number(formData.cubagem)
      });
    } catch (err) {
      toast({ title: "Erro na simulação", variant: "destructive" });
    }
  };

  const handleSelect = async (operatorId: number, price: number, deadline: number) => {
    try {
      await createRequest({
        origem: formData.origem,
        destino: formData.destino,
        peso: Number(formData.peso),
        cubagem: Number(formData.cubagem),
        recommendedOperatorId: operatorId,
        valorEstimado: price.toString(),
        prazoEstimado: deadline,
      });
      toast({ title: "Solicitação criada com sucesso!" });
      setLocation("/requests");
    } catch (err) {
      toast({ title: "Erro ao criar solicitação", variant: "destructive" });
    }
  };

  // Prepare radar chart data if results exist
  const radarData = results?.map(r => ({
    subject: r.operatorName,
    A: r.score, // Score calculated by backend (price/deadline balance)
    fullMark: 100,
  }));

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-slate-900">Simulador de Frete</h2>
        <p className="text-slate-500 mt-2">Compare preços e prazos entre os operadores parceiros.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Input Form */}
        <Card className="md:col-span-1 h-fit shadow-lg">
          <CardHeader>
            <CardTitle>Dados da Carga</CardTitle>
            <CardDescription>Preencha para cotar</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSimulate} className="space-y-4">
              <div className="space-y-2">
                <Label>Cidade Origem</Label>
                <Input 
                  value={formData.origem}
                  onChange={e => setFormData({...formData, origem: e.target.value})}
                  placeholder="Ex: São Paulo"
                />
              </div>
              <div className="space-y-2">
                <Label>Cidade Destino</Label>
                <Input 
                  value={formData.destino}
                  onChange={e => setFormData({...formData, destino: e.target.value})}
                  placeholder="Ex: Curitiba"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Peso (kg)</Label>
                  <Input 
                    type="number"
                    value={formData.peso}
                    onChange={e => setFormData({...formData, peso: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Volume (m³)</Label>
                  <Input 
                    type="number"
                    value={formData.cubagem}
                    onChange={e => setFormData({...formData, cubagem: e.target.value})}
                  />
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={isSimulating}>
                {isSimulating ? <Loader2 className="animate-spin mr-2" /> : "Cotar Agora"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Results Area */}
        <div className="md:col-span-2 space-y-6">
          {!results && !isSimulating && (
            <div className="h-full flex flex-col items-center justify-center p-12 border-2 border-dashed rounded-xl text-slate-400 bg-slate-50/50">
              <Radar className="h-16 w-16 mb-4 text-slate-300" />
              <p>Preencha os dados ao lado para ver as cotações</p>
            </div>
          )}

          {results && (
            <>
              {/* Comparison Chart */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm uppercase tracking-wide text-slate-500">Comparativo de Score</CardTitle>
                </CardHeader>
                <CardContent className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                      <PolarGrid stroke="#e2e8f0" />
                      <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 12 }} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                      <Radar
                        name="Score"
                        dataKey="A"
                        stroke="#3b82f6"
                        strokeWidth={2}
                        fill="#3b82f6"
                        fillOpacity={0.3}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Offer Cards */}
              <div className="space-y-4">
                {results.map((result, idx) => (
                  <div 
                    key={result.operatorId}
                    className={`
                      relative flex items-center justify-between p-6 rounded-xl border transition-all duration-300
                      ${idx === 0 
                        ? 'bg-blue-50/50 border-blue-200 shadow-md ring-1 ring-blue-500/20' 
                        : 'bg-white border-slate-200 hover:border-blue-300'
                      }
                    `}
                  >
                    {idx === 0 && (
                      <div className="absolute -top-3 left-6 bg-blue-600 text-white text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1 shadow-sm">
                        <Trophy className="h-3 w-3" /> MELHOR OPÇÃO
                      </div>
                    )}
                    
                    <div>
                      <h4 className="font-bold text-lg text-slate-900">{result.operatorName}</h4>
                      <p className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                        <span className="font-medium text-slate-700">Prazo: {result.deadline} dias</span>
                        <span className="w-1 h-1 rounded-full bg-slate-300" />
                        <span>Score: {result.score.toFixed(1)}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-2xl font-bold text-slate-900">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(result.price)}
                        </p>
                        <p className="text-xs text-slate-500">Valor total</p>
                      </div>
                      <Button 
                        onClick={() => handleSelect(result.operatorId, result.price, result.deadline)}
                        disabled={isCreating}
                        className={idx === 0 ? "" : "bg-white text-slate-900 border border-slate-200 hover:bg-slate-50"}
                      >
                        {isCreating ? <Loader2 className="animate-spin" /> : "Contratar"}
                        {!isCreating && <ArrowRight className="ml-2 h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
