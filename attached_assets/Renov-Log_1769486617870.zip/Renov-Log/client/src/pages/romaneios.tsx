import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  ClipboardList, 
  Truck, 
  Package, 
  MapPin,
  Calendar,
  Filter,
  Eye,
  FileText,
  Loader2
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

type StatusRomaneio = "aguardando" | "em_transito" | "entregue" | "parcial" | "cancelado";

interface Romaneio {
  id: string;
  numero: string;
  dataEmissao: Date;
  operador: string;
  motorista: string;
  placa: string;
  origem: string;
  destino: string;
  status: StatusRomaneio;
  totalVolumes: number;
  volumesEntregues: number;
  valorTotal: number;
}

const STATUS_CONFIG: Record<StatusRomaneio, { label: string; className: string }> = {
  aguardando: { label: "Aguardando", className: "bg-yellow-100 text-yellow-800 border-yellow-200" },
  em_transito: { label: "Em Trânsito", className: "bg-blue-100 text-blue-800 border-blue-200" },
  entregue: { label: "Entregue", className: "bg-green-100 text-green-800 border-green-200" },
  parcial: { label: "Entrega Parcial", className: "bg-orange-100 text-orange-800 border-orange-200" },
  cancelado: { label: "Cancelado", className: "bg-red-100 text-red-800 border-red-200" },
};

const mockRomaneios: Romaneio[] = [
  {
    id: "1",
    numero: "ROM-2026-00145",
    dataEmissao: new Date("2026-01-19T08:30:00"),
    operador: "RapidCargo Logística",
    motorista: "João da Silva",
    placa: "ABC-1234",
    origem: "São Paulo, SP",
    destino: "Rio de Janeiro, RJ",
    status: "em_transito",
    totalVolumes: 45,
    volumesEntregues: 0,
    valorTotal: 12500.00,
  },
  {
    id: "2",
    numero: "ROM-2026-00144",
    dataEmissao: new Date("2026-01-18T14:00:00"),
    operador: "TransNacional Transportes",
    motorista: "Pedro Santos",
    placa: "DEF-5678",
    origem: "Belo Horizonte, MG",
    destino: "Curitiba, PR",
    status: "entregue",
    totalVolumes: 32,
    volumesEntregues: 32,
    valorTotal: 8900.00,
  },
  {
    id: "3",
    numero: "ROM-2026-00143",
    dataEmissao: new Date("2026-01-18T10:15:00"),
    operador: "ExpressBR",
    motorista: "Carlos Oliveira",
    placa: "GHI-9012",
    origem: "Porto Alegre, RS",
    destino: "Florianópolis, SC",
    status: "parcial",
    totalVolumes: 28,
    volumesEntregues: 20,
    valorTotal: 6750.00,
  },
  {
    id: "4",
    numero: "ROM-2026-00142",
    dataEmissao: new Date("2026-01-17T16:45:00"),
    operador: "LogiFast",
    motorista: "Marcos Lima",
    placa: "JKL-3456",
    origem: "Campinas, SP",
    destino: "Ribeirão Preto, SP",
    status: "aguardando",
    totalVolumes: 15,
    volumesEntregues: 0,
    valorTotal: 3200.00,
  },
];

export default function RomaneiosPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isLoading] = useState(false);

  const filteredRomaneios = mockRomaneios.filter(rom => {
    const matchesSearch = 
      rom.numero.toLowerCase().includes(search.toLowerCase()) ||
      rom.operador.toLowerCase().includes(search.toLowerCase()) ||
      rom.motorista.toLowerCase().includes(search.toLowerCase()) ||
      rom.placa.toLowerCase().includes(search.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || rom.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const statsCards = [
    { 
      title: "Total de Romaneios", 
      value: mockRomaneios.length, 
      icon: ClipboardList, 
      borderClass: "border-l-blue-500" 
    },
    { 
      title: "Em Trânsito", 
      value: mockRomaneios.filter(r => r.status === "em_transito").length, 
      icon: Truck, 
      borderClass: "border-l-yellow-500" 
    },
    { 
      title: "Entregues Hoje", 
      value: mockRomaneios.filter(r => r.status === "entregue").length, 
      icon: Package, 
      borderClass: "border-l-green-500" 
    },
    { 
      title: "Aguardando", 
      value: mockRomaneios.filter(r => r.status === "aguardando").length, 
      icon: Calendar, 
      borderClass: "border-l-orange-500" 
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-slate-900">Romaneios</h2>
        <p className="text-slate-500 mt-2">Consulte e acompanhe o status dos romaneios de carga.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statsCards.map((stat, index) => (
          <Card key={index} className={`hover:shadow-md transition-shadow duration-200 border-l-4 ${stat.borderClass}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros de Busca
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input 
                placeholder="Buscar por número, operador, motorista ou placa..." 
                className="pl-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                data-testid="input-search-romaneio"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[200px]" data-testid="select-status-filter">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="aguardando">Aguardando</SelectItem>
                <SelectItem value="em_transito">Em Trânsito</SelectItem>
                <SelectItem value="entregue">Entregue</SelectItem>
                <SelectItem value="parcial">Entrega Parcial</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Romaneios</CardTitle>
          <CardDescription>
            {filteredRomaneios.length} romaneio(s) encontrado(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-xl overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow>
                  <TableHead>Número</TableHead>
                  <TableHead>Data Emissão</TableHead>
                  <TableHead>Operador</TableHead>
                  <TableHead>Motorista / Placa</TableHead>
                  <TableHead>Rota</TableHead>
                  <TableHead>Volumes</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" />
                    </TableCell>
                  </TableRow>
                ) : filteredRomaneios.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                      Nenhum romaneio encontrado.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRomaneios.map((rom) => (
                    <TableRow key={rom.id} className="hover:bg-slate-50/50">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-slate-400" />
                          <span className="font-mono text-sm font-medium">{rom.numero}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">
                        {format(rom.dataEmissao, "dd/MM/yyyy HH:mm", { locale: ptBR })}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Truck className="h-4 w-4 text-slate-400" />
                          <span className="text-sm">{rom.operador}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <p className="font-medium">{rom.motorista}</p>
                          <p className="text-xs text-slate-500">{rom.placa}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="h-3 w-3 text-slate-400" />
                          <span>{rom.origem}</span>
                          <span className="text-slate-400">→</span>
                          <span>{rom.destino}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <span className="font-medium">{rom.volumesEntregues}</span>
                          <span className="text-slate-400"> / {rom.totalVolumes}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={STATUS_CONFIG[rom.status].className}>
                          {STATUS_CONFIG[rom.status].label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" data-testid={`button-view-romaneio-${rom.id}`}>
                          <Eye className="h-4 w-4 mr-1" />
                          Detalhes
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
