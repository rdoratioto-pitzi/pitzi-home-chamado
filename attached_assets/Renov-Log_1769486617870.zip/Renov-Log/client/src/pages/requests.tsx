import { useRequests } from "@/hooks/use-logistics";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Package, Search, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const STATUS_VARIANTS: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  pending: "secondary",
  quoted: "outline",
  approved: "default",
  collected: "default",
  delivered: "default",
  cancelled: "destructive",
};

export default function RequestsPage() {
  const { data: requests, isLoading } = useRequests();
  const [filter, setFilter] = useState("");

  const filteredRequests = requests?.filter((req: any) => 
    req.id.toString().includes(filter) ||
    req.origem.toLowerCase().includes(filter.toLowerCase()) ||
    req.destino.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-slate-900">Solicitações de Coleta</h2>
        <p className="text-slate-500 mt-2">Acompanhe o status de todas as coletas solicitadas.</p>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Filtrar por ID, Origem ou Destino..." 
            className="pl-10 bg-white"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        </div>
      </div>

      <div className="border rounded-xl bg-white shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-slate-50">
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Origem → Destino</TableHead>
              <TableHead>Carga</TableHead>
              <TableHead>Valor Estimado</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Criado em</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" />
                </TableCell>
              </TableRow>
            ) : filteredRequests?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-slate-500">
                  Nenhuma solicitação encontrada.
                </TableCell>
              </TableRow>
            ) : (
              filteredRequests?.map((req: any) => (
                <TableRow key={req.id} className="hover:bg-slate-50/50">
                  <TableCell className="font-mono font-medium">#{req.id}</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium">{req.origem}</span>
                      <span className="text-xs text-slate-500">para {req.destino}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {req.peso} kg <span className="text-slate-400 mx-1">•</span> {req.cubagem} m³
                    </div>
                  </TableCell>
                  <TableCell>
                    {req.valorEstimado 
                      ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(req.valorEstimado))
                      : "-"
                    }
                  </TableCell>
                  <TableCell>
                    <Badge variant={STATUS_VARIANTS[req.status] || "outline"}>
                      {req.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-slate-500">
                    {format(new Date(req.createdAt), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">Rastrear</Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
