import { useDashboardStats, useRequests } from "@/hooks/use-logistics";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Package, 
  DollarSign, 
  Clock, 
  TrendingUp,
  Loader2,
  Truck,
  Activity
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Progress } from "@/components/ui/progress";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  quoted: "bg-blue-100 text-blue-800 border-blue-200",
  approved: "bg-indigo-100 text-indigo-800 border-indigo-200",
  collected: "bg-purple-100 text-purple-800 border-purple-200",
  delivered: "bg-green-100 text-green-800 border-green-200",
  cancelled: "bg-red-100 text-red-800 border-red-200",
};

const STATUS_LABELS: Record<string, string> = {
  pending: "Pendente",
  quoted: "Cotado",
  approved: "Aprovado",
  collected: "Coletado",
  delivered: "Entregue",
  cancelled: "Cancelado",
};

export default function DashboardPage() {
  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const { data: requests, isLoading: requestsLoading } = useRequests();

  if (statsLoading || requestsLoading) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  const chartData = [
    { name: 'Seg', total: 4 },
    { name: 'Ter', total: 7 },
    { name: 'Qua', total: 5 },
    { name: 'Qui', total: 10 },
    { name: 'Sex', total: 8 },
    { name: 'Sáb', total: 3 },
    { name: 'Dom', total: 2 },
  ];

  const pieData = [
    { name: 'Transp A', value: 400 },
    { name: 'Transp B', value: 300 },
    { name: 'Transp C', value: 300 },
    { name: 'Outros', value: 200 },
  ];
  const COLORS = ['#3b82f6', '#06b6d4', '#8b5cf6', '#64748b'];

  const dispositivosStatus = {
    aguardando: 789,
    confirmado: 456,
    emColeta: 3194,
  };
  const totalDispositivos = dispositivosStatus.aguardando + dispositivosStatus.confirmado + dispositivosStatus.emColeta;

  const custoMedioPorOperador = [
    { operador: "RapidCargo Logística", custoMedio: 12.50, entregas: 1250 },
    { operador: "TransNacional Transportes", custoMedio: 14.20, entregas: 980 },
    { operador: "ExpressBR", custoMedio: 11.80, entregas: 750 },
    { operador: "LogiFast", custoMedio: 13.90, entregas: 620 },
  ];
  const custoMedioGeral = custoMedioPorOperador.reduce((acc, op) => acc + op.custoMedio, 0) / custoMedioPorOperador.length;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-slate-900">Dashboard</h2>
        <p className="text-slate-500 mt-2">Visão geral da operação logística e indicadores de performance.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="hover:shadow-md transition-shadow duration-200 border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Solicitações de Coleta</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalRequests || 0}</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
              <span className="text-green-600 font-medium">+20.1%</span> vs mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow duration-200 border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats?.totalValue || 0)}
            </div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
              <span className="text-green-600 font-medium">+15%</span> crescimento
            </p>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow duration-200 border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Entregas no Prazo</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.onTimeRate || 0}%</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
              <span className="text-red-600 font-medium">-2%</span> vs meta (98%)
            </p>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow duration-200 border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Economia Gerada</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats?.savings || 0)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Através da otimização de rotas
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              Status Meus Dispositivos
            </CardTitle>
            <CardDescription>Visão geral do status atual dos dispositivos</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <span className="text-sm font-medium">Aguardando</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-lg font-bold">{dispositivosStatus.aguardando.toLocaleString('pt-BR')}</span>
                  <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                    {((dispositivosStatus.aguardando / totalDispositivos) * 100).toFixed(1)}%
                  </Badge>
                </div>
              </div>
              <Progress value={(dispositivosStatus.aguardando / totalDispositivos) * 100} className="h-2 bg-yellow-100" />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-sm font-medium">Confirmado</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-lg font-bold">{dispositivosStatus.confirmado.toLocaleString('pt-BR')}</span>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {((dispositivosStatus.confirmado / totalDispositivos) * 100).toFixed(1)}%
                  </Badge>
                </div>
              </div>
              <Progress value={(dispositivosStatus.confirmado / totalDispositivos) * 100} className="h-2 bg-blue-100" />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-sm font-medium">Em Coleta</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-lg font-bold">{dispositivosStatus.emColeta.toLocaleString('pt-BR')}</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    {((dispositivosStatus.emColeta / totalDispositivos) * 100).toFixed(1)}%
                  </Badge>
                </div>
              </div>
              <Progress value={(dispositivosStatus.emColeta / totalDispositivos) * 100} className="h-2 bg-green-100" />
            </div>

            <div className="pt-4 border-t">
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Total de Dispositivos</span>
                <span className="font-bold text-slate-900">{totalDispositivos.toLocaleString('pt-BR')}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-primary" />
              Custo Unitário Médio de Frete
            </CardTitle>
            <CardDescription>Custo médio por operador logístico</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6 p-4 bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg">
              <p className="text-sm text-muted-foreground">Custo Médio Geral</p>
              <p className="text-3xl font-bold text-primary">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(custoMedioGeral)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">Por unidade transportada</p>
            </div>

            <div className="space-y-4">
              {custoMedioPorOperador.map((op, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center">
                      <Truck className="h-4 w-4 text-slate-500" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{op.operador}</p>
                      <p className="text-xs text-muted-foreground">{op.entregas.toLocaleString('pt-BR')} entregas</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-slate-900">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(op.custoMedio)}
                    </p>
                    <p className="text-xs text-muted-foreground">por unidade</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Volume de Envios Diários</CardTitle>
            <CardDescription>Últimos 7 dias</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis 
                    dataKey="name" 
                    stroke="#888888" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="#888888" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `${value}`} 
                  />
                  <Tooltip 
                    cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="total" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Distribuição por Operador</CardTitle>
            <CardDescription>Share de volume atual</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-4 text-xs text-muted-foreground mt-4 flex-wrap">
              {pieData.map((entry, index) => (
                <div key={entry.name} className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                  {entry.name}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Solicitações Recentes</CardTitle>
          <CardDescription>Últimas movimentações registradas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {requests?.slice(0, 5).map((req: any) => (
              <div key={req.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center">
                    <Package className="h-5 w-5 text-slate-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">
                      {req.origem} → {req.destino}
                    </p>
                    <p className="text-xs text-slate-500">
                      ID: #{req.id} • {format(new Date(req.createdAt), "dd 'de' MMM, HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge variant="outline" className={STATUS_COLORS[req.status] || "bg-slate-100"}>
                    {STATUS_LABELS[req.status] || req.status}
                  </Badge>
                  <div className="text-right text-sm">
                    <p className="font-medium text-slate-900">
                      {req.valorEstimado ? `R$ ${req.valorEstimado}` : "-"}
                    </p>
                    <p className="text-xs text-slate-500">
                      {req.peso} kg
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {(!requests || requests.length === 0) && (
              <div className="text-center py-8 text-slate-500">
                Nenhuma solicitação encontrada.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
