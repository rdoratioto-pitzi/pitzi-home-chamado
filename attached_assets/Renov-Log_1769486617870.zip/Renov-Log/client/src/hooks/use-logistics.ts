import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertOperator, InsertRequest } from "@shared/schema";

// --- Operators ---
export function useOperators() {
  return useQuery({
    queryKey: [api.operators.list.path],
    queryFn: async () => {
      const res = await fetch(api.operators.list.path);
      if (!res.ok) throw new Error("Failed to fetch operators");
      return api.operators.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateOperator() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertOperator) => {
      const validated = api.operators.create.input.parse(data);
      const res = await fetch(api.operators.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to create operator");
      return api.operators.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.operators.list.path] });
    },
  });
}

// --- Requests ---
export function useRequests() {
  return useQuery({
    queryKey: [api.requests.list.path],
    queryFn: async () => {
      const res = await fetch(api.requests.list.path);
      if (!res.ok) throw new Error("Failed to fetch requests");
      return api.requests.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateRequest() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertRequest) => {
      const validated = api.requests.create.input.parse(data);
      const res = await fetch(api.requests.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to create request");
      return api.requests.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.requests.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.dashboard.stats.path] });
    },
  });
}

export function useSimulateRequest() {
  return useMutation({
    mutationFn: async (data: { origem: string; destino: string; peso: number; cubagem: number }) => {
      const res = await fetch(api.requests.simulate.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Simulation failed");
      return api.requests.simulate.responses[200].parse(await res.json());
    },
  });
}

export function useRequestDetails(id: number) {
  return useQuery({
    queryKey: [api.requests.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.requests.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch request details");
      return api.requests.get.responses[200].parse(await res.json());
    },
  });
}

// --- CTEs ---
export function useCtes() {
  return useQuery({
    queryKey: [api.cte.list.path],
    queryFn: async () => {
      const res = await fetch(api.cte.list.path);
      if (!res.ok) throw new Error("Failed to fetch CTEs");
      return api.cte.list.responses[200].parse(await res.json());
    },
  });
}

// --- Dashboard ---
export function useDashboardStats() {
  return useQuery({
    queryKey: [api.dashboard.stats.path],
    queryFn: async () => {
      const res = await fetch(api.dashboard.stats.path);
      if (!res.ok) throw new Error("Failed to fetch stats");
      return api.dashboard.stats.responses[200].parse(await res.json());
    },
  });
}
