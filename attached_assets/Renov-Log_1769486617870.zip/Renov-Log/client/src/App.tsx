import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { LayoutShell } from "@/components/layout-shell";
import { Loader2 } from "lucide-react";

// Páginas
import AuthPage from "@/pages/auth";
import DashboardPage from "@/pages/dashboard";
import OperatorsPage from "@/pages/operators";
import RequestsPage from "@/pages/requests";
import SimulationPage from "@/pages/simulation";
import CtePage from "@/pages/cte";
import RomaneiosPage from "@/pages/romaneios";
import LogisticaReversaPage from "@/pages/logistica-reversa";
import ApisPage from "@/pages/apis";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Acesso automático - sempre permite acesso (auto-login está habilitado)
  return (
    <LayoutShell>
      <Component />
    </LayoutShell>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      
      <Route path="/">
        <ProtectedRoute component={DashboardPage} />
      </Route>
      
      <Route path="/operators">
        <ProtectedRoute component={OperatorsPage} />
      </Route>
      
      <Route path="/requests">
        <ProtectedRoute component={RequestsPage} />
      </Route>
      
      <Route path="/simulation">
        <ProtectedRoute component={SimulationPage} />
      </Route>
      
      <Route path="/cte">
        <ProtectedRoute component={CtePage} />
      </Route>
      
      <Route path="/romaneios">
        <ProtectedRoute component={RomaneiosPage} />
      </Route>
      
      <Route path="/logistica-reversa">
        <ProtectedRoute component={LogisticaReversaPage} />
      </Route>
      
      <Route path="/apis">
        <ProtectedRoute component={ApisPage} />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
