import { 
  User, InsertUser, 
  LogisticOperator, InsertOperator, 
  OperatorCoverage, InsertCoverage,
  PriceTable, InsertPrice,
  CollectionRequest, InsertRequest, RequestWithDetails,
  CteEmission, InsertCte,
  TrackingStatus, InsertTracking,
  IntegrationLog,
  LogisticaReversaPedido, InsertLogisticaReversaPedido, LogisticaReversaPedidoWithEventos,
  LogisticaReversaEvento, InsertLogisticaReversaEvento,
  users, logisticOperators, operatorCoverage, priceTables, collectionRequests, cteEmissions, trackingStatus, integrationLogs,
  logisticaReversaPedidos, logisticaReversaEventos
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Operators
  getOperators(): Promise<LogisticOperator[]>;
  getOperator(id: number): Promise<LogisticOperator | undefined>;
  createOperator(operator: InsertOperator): Promise<LogisticOperator>;
  updateOperator(id: number, updates: Partial<LogisticOperator>): Promise<LogisticOperator>;

  // Coverage
  getCoverage(operatorId: number): Promise<OperatorCoverage[]>;
  addCoverage(coverage: InsertCoverage): Promise<OperatorCoverage>;

  // Prices
  getPrices(operatorId: number): Promise<PriceTable[]>;
  addPrice(price: InsertPrice): Promise<PriceTable>;

  // Requests
  getRequests(): Promise<RequestWithDetails[]>;
  getRequest(id: number): Promise<RequestWithDetails | undefined>;
  createRequest(request: InsertRequest): Promise<CollectionRequest>;
  updateRequestStatus(id: number, status: string): Promise<CollectionRequest>;
  
  // CT-e
  getCTEs(): Promise<CteEmission[]>;
  createCTE(cte: InsertCte): Promise<CteEmission>;

  // Tracking
  getTracking(requestId: number): Promise<TrackingStatus[]>;
  addTracking(tracking: InsertTracking): Promise<TrackingStatus>;

  // Integration Logs
  addIntegrationLog(log: Omit<IntegrationLog, "id" | "timestamp">): Promise<IntegrationLog>;
  getIntegrationLogs(tipoApi?: string, limit?: number): Promise<IntegrationLog[]>;

  // Logística Reversa
  createLogisticaReversaPedido(pedido: InsertLogisticaReversaPedido): Promise<LogisticaReversaPedido>;
  getLogisticaReversaPedidos(): Promise<LogisticaReversaPedidoWithEventos[]>;
  getLogisticaReversaPedido(id: number): Promise<LogisticaReversaPedidoWithEventos | undefined>;
  getLogisticaReversaPedidoByNumero(numeroPedido: string): Promise<LogisticaReversaPedidoWithEventos | undefined>;
  updateLogisticaReversaPedido(id: number, updates: Partial<LogisticaReversaPedido>): Promise<LogisticaReversaPedido>;
  addLogisticaReversaEvento(evento: InsertLogisticaReversaEvento): Promise<LogisticaReversaEvento>;
  getLogisticaReversaStats(): Promise<{ total: number; pendentes: number; concluidos: number; cancelados: number }>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Operators
  async getOperators(): Promise<LogisticOperator[]> {
    return await db.select().from(logisticOperators).orderBy(desc(logisticOperators.createdAt));
  }

  async getOperator(id: number): Promise<LogisticOperator | undefined> {
    const [op] = await db.select().from(logisticOperators).where(eq(logisticOperators.id, id));
    return op;
  }

  async createOperator(operator: InsertOperator): Promise<LogisticOperator> {
    const [newOp] = await db.insert(logisticOperators).values(operator).returning();
    return newOp;
  }

  async updateOperator(id: number, updates: Partial<LogisticOperator>): Promise<LogisticOperator> {
    const [updated] = await db.update(logisticOperators).set(updates).where(eq(logisticOperators.id, id)).returning();
    return updated;
  }

  // Coverage
  async getCoverage(operatorId: number): Promise<OperatorCoverage[]> {
    return await db.select().from(operatorCoverage).where(eq(operatorCoverage.operatorId, operatorId));
  }

  async addCoverage(coverage: InsertCoverage): Promise<OperatorCoverage> {
    const [newCov] = await db.insert(operatorCoverage).values(coverage).returning();
    return newCov;
  }

  // Prices
  async getPrices(operatorId: number): Promise<PriceTable[]> {
    return await db.select().from(priceTables).where(eq(priceTables.operatorId, operatorId));
  }

  async addPrice(price: InsertPrice): Promise<PriceTable> {
    const [newPrice] = await db.insert(priceTables).values(price).returning();
    return newPrice;
  }

  // Requests
  async getRequests(): Promise<RequestWithDetails[]> {
    return await db.query.collectionRequests.findMany({
      orderBy: desc(collectionRequests.createdAt),
      with: {
        operator: true,
        client: true,
        tracking: true
      }
    });
  }

  async getRequest(id: number): Promise<RequestWithDetails | undefined> {
    return await db.query.collectionRequests.findFirst({
      where: eq(collectionRequests.id, id),
      with: {
        operator: true,
        client: true,
        tracking: {
          orderBy: desc(trackingStatus.dataHora)
        },
        cte: true
      }
    });
  }

  async createRequest(request: InsertRequest): Promise<CollectionRequest> {
    const [newReq] = await db.insert(collectionRequests).values(request).returning();
    return newReq;
  }

  async updateRequestStatus(id: number, status: string): Promise<CollectionRequest> {
    const [updated] = await db.update(collectionRequests).set({ status }).where(eq(collectionRequests.id, id)).returning();
    return updated;
  }

  // CT-e
  async getCTEs(): Promise<CteEmission[]> {
    return await db.select().from(cteEmissions).orderBy(desc(cteEmissions.createdAt));
  }

  async createCTE(cte: InsertCte): Promise<CteEmission> {
    const [newCte] = await db.insert(cteEmissions).values(cte).returning();
    return newCte;
  }

  // Tracking
  async getTracking(requestId: number): Promise<TrackingStatus[]> {
    return await db.select().from(trackingStatus).where(eq(trackingStatus.requestId, requestId)).orderBy(desc(trackingStatus.dataHora));
  }

  async addTracking(tracking: InsertTracking): Promise<TrackingStatus> {
    const [newTrack] = await db.insert(trackingStatus).values(tracking).returning();
    return newTrack;
  }

  // Integration Logs
  async addIntegrationLog(log: Omit<IntegrationLog, "id" | "timestamp">): Promise<IntegrationLog> {
    const [newLog] = await db.insert(integrationLogs).values(log).returning();
    return newLog;
  }

  async getIntegrationLogs(tipoApi?: string, limit: number = 50): Promise<IntegrationLog[]> {
    if (tipoApi) {
      return await db.select().from(integrationLogs)
        .where(eq(integrationLogs.tipoApi, tipoApi))
        .orderBy(desc(integrationLogs.timestamp))
        .limit(limit);
    }
    return await db.select().from(integrationLogs)
      .orderBy(desc(integrationLogs.timestamp))
      .limit(limit);
  }

  // Logística Reversa
  async createLogisticaReversaPedido(pedido: InsertLogisticaReversaPedido): Promise<LogisticaReversaPedido> {
    const [newPedido] = await db.insert(logisticaReversaPedidos).values(pedido).returning();
    return newPedido;
  }

  async getLogisticaReversaPedidos(): Promise<LogisticaReversaPedidoWithEventos[]> {
    return await db.query.logisticaReversaPedidos.findMany({
      orderBy: desc(logisticaReversaPedidos.createdAt),
      with: {
        eventos: true,
      },
    });
  }

  async getLogisticaReversaPedido(id: number): Promise<LogisticaReversaPedidoWithEventos | undefined> {
    return await db.query.logisticaReversaPedidos.findFirst({
      where: eq(logisticaReversaPedidos.id, id),
      with: {
        eventos: {
          orderBy: desc(logisticaReversaEventos.dataEvento),
        },
      },
    });
  }

  async getLogisticaReversaPedidoByNumero(numeroPedido: string): Promise<LogisticaReversaPedidoWithEventos | undefined> {
    return await db.query.logisticaReversaPedidos.findFirst({
      where: eq(logisticaReversaPedidos.numeroPedido, numeroPedido),
      with: {
        eventos: {
          orderBy: desc(logisticaReversaEventos.dataEvento),
        },
      },
    });
  }

  async updateLogisticaReversaPedido(id: number, updates: Partial<LogisticaReversaPedido>): Promise<LogisticaReversaPedido> {
    const [updated] = await db.update(logisticaReversaPedidos)
      .set({ ...updates, dataUltimaAtualizacao: new Date() })
      .where(eq(logisticaReversaPedidos.id, id))
      .returning();
    return updated;
  }

  async addLogisticaReversaEvento(evento: InsertLogisticaReversaEvento): Promise<LogisticaReversaEvento> {
    const [newEvento] = await db.insert(logisticaReversaEventos).values(evento).returning();
    return newEvento;
  }

  async getLogisticaReversaStats(): Promise<{ total: number; pendentes: number; concluidos: number; cancelados: number }> {
    const pedidos = await db.select().from(logisticaReversaPedidos);
    const total = pedidos.length;
    const pendentes = pedidos.filter(p => ["solicitado", "aguardando_postagem", "coletado", "em_transito"].includes(p.status)).length;
    const concluidos = pedidos.filter(p => p.status === "entregue").length;
    const cancelados = pedidos.filter(p => p.status === "cancelado").length;
    return { total, pendentes, concluidos, cancelados };
  }
}

export const storage = new DatabaseStorage();
