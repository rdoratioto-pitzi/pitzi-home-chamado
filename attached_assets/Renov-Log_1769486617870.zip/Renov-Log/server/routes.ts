import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { rastrearObjeto, getIntegrationStatus, CorreiosError } from "./services/correios";
import * as logisticaReversa from "./services/correios-logistica-reversa";

const enderecoSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório").max(100),
  logradouro: z.string().min(1, "Logradouro é obrigatório").max(100),
  numero: z.string().min(1, "Número é obrigatório").max(10),
  complemento: z.string().max(50).optional().default(""),
  bairro: z.string().min(1, "Bairro é obrigatório").max(50),
  cep: z.string().regex(/^\d{8}$|^\d{5}-?\d{3}$/, "CEP deve ter 8 dígitos"),
  cidade: z.string().min(1, "Cidade é obrigatória").max(50),
  uf: z.string().length(2, "UF deve ter 2 caracteres").toUpperCase(),
  ddd: z.string().max(2).optional().default(""),
  telefone: z.string().max(15).optional().default(""),
  email: z.string().email("Email inválido").optional().or(z.literal("")).default(""),
});

const objetoSchema = z.object({
  descricao: z.string().min(1).max(100).optional(),
  numero: z.string().max(20).optional(),
}).optional();

const itemColetaSchema = z.object({
  descricao: z.string().min(1, "Descrição é obrigatória").max(100),
  quantidade: z.number().int().min(1).default(1),
  valorUnitario: z.number().min(0).default(0),
});

const solicitarLRSchema = z.object({
  tipo: z.enum(["A", "C", "CA"]).optional().default("A"),
  codigoServico: z.enum(["41076", "40010", "40215", "40290"]).optional().default("41076"),
  remetente: enderecoSchema,
  destinatario: enderecoSchema,
  objeto: objetoSchema,
  observacao: z.string().max(1000).optional().default(""),
  itens: z.array(itemColetaSchema).optional().default([]),
  tipoEmbalagem: z.string().max(50).optional().default(""),
  adicionalArtigoPerigoso: z.boolean().optional().default(true),
  valorDeclarado: z.number().min(0).optional().default(0),
});

const remetenteMassaSchema = z.object({
  nome: z.string().min(1).max(100),
  logradouro: z.string().min(1).max(100),
  numero: z.string().min(1).max(10),
  complemento: z.string().max(50).optional().default(""),
  bairro: z.string().min(1).max(50),
  cep: z.string().regex(/^\d{5,8}$|^\d{5}-?\d{3}$/, "CEP inválido"),
  cidade: z.string().min(1).max(50),
  uf: z.string().length(2).toUpperCase(),
  ddd: z.string().max(2).optional().default(""),
  telefone: z.string().max(15).optional().default(""),
  email: z.string().email().optional().or(z.literal("")).default(""),
});

const solicitarMassaSchema = z.object({
  solicitacoes: z.array(z.object({
    tipo: z.enum(["A", "C", "CA"]).optional().default("A"),
    remetente: remetenteMassaSchema,
  })).min(1, "Pelo menos uma solicitação é necessária").max(50, "Máximo de 50 solicitações"),
  destinatario: enderecoSchema,
  codigoServico: z.enum(["41076", "40010", "40215", "40290"]).optional().default("41076"),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Authentication
  setupAuth(app);

  // === USERS ===
  app.get(api.users.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.post(api.users.create.path, async (req, res) => {
    // Basic registration - normally should be protected or public
    try {
      const input = api.users.create.input.parse(req.body);
      const existing = await storage.getUserByUsername(input.email);
      if (existing) {
        return res.status(400).json({ message: "User already exists" });
      }
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // === OPERATORS ===
  app.get(api.operators.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const operators = await storage.getOperators();
    res.json(operators);
  });

  app.get(api.operators.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const op = await storage.getOperator(Number(req.params.id));
    if (!op) return res.status(404).json({ message: "Operator not found" });
    res.json(op);
  });

  app.post(api.operators.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.operators.create.input.parse(req.body);
      const op = await storage.createOperator(input);
      res.status(201).json(op);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // === COVERAGE & PRICES ===
  app.get(api.coverage.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const coverage = await storage.getCoverage(Number(req.params.operatorId));
    res.json(coverage);
  });

  app.post(api.coverage.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.coverage.create.input.parse(req.body);
      const cov = await storage.addCoverage({ ...input, operatorId: Number(req.params.operatorId) });
      res.status(201).json(cov);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.get(api.prices.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const prices = await storage.getPrices(Number(req.params.operatorId));
    res.json(prices);
  });

  app.post(api.prices.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.prices.create.input.parse(req.body);
      const price = await storage.addPrice({ ...input, operatorId: Number(req.params.operatorId) });
      res.status(201).json(price);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // === REQUESTS & SIMULATION ===
  app.get(api.requests.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const requests = await storage.getRequests();
    res.json(requests);
  });

  app.get(api.requests.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const request = await storage.getRequest(Number(req.params.id));
    if (!request) return res.status(404).json({ message: "Request not found" });
    res.json(request);
  });

  app.post(api.requests.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.requests.create.input.parse(req.body);
      const request = await storage.createRequest(input);
      // Create initial tracking status
      await storage.addTracking({
        requestId: request.id,
        status: "Solicitação Criada",
        localizacao: "Sistema",
        observacao: "Aguardando coleta"
      });
      res.status(201).json(request);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.requests.simulate.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const { origem, destino, peso, cubagem } = api.requests.simulate.input.parse(req.body);
      
      // Algorithm Logic Mockup:
      // 1. Get all operators
      // 2. Filter by coverage (Mock: Randomly available for now as we don't have full state matrix)
      // 3. Calculate price (Mock: base price * weight)
      // 4. Calculate score
      
      const operators = await storage.getOperators();
      
      const simulationResults = operators.map(op => {
        const basePrice = 15.0; // Mock base
        const weightFactor = Number(peso) * 2.5;
        const randomVar = Math.random() * 10;
        
        const price = basePrice + weightFactor + randomVar;
        const deadline = Math.floor(Math.random() * 5) + 2; // 2-7 days
        
        // Score: 60% price, 40% deadline (inverted, lower is better)
        // Normalized score 0-100 (higher is better)
        const score = Math.max(0, 100 - (price * 0.6 + deadline * 4));
        
        return {
          operatorId: op.id,
          operatorName: op.razaoSocial,
          price: Number(price.toFixed(2)),
          deadline,
          score: Number(score.toFixed(0)),
        };
      }).sort((a, b) => b.score - a.score); // Best score first

      res.json(simulationResults);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // === CTE & TRACKING ===
  app.get(api.cte.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const ctes = await storage.getCTEs();
    res.json(ctes);
  });

  app.get(api.tracking.history.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const tracking = await storage.getTracking(Number(req.params.requestId));
    res.json(tracking);
  });

  app.post(api.tracking.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.tracking.update.input.parse(req.body);
      const track = await storage.addTracking({ ...input, requestId: Number(req.params.requestId) });
      res.status(201).json(track);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // === DASHBOARD ===
  app.get(api.dashboard.stats.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    // Calculate stats
    const requests = await storage.getRequests();
    
    const totalRequests = requests.length;
    const totalValue = requests.reduce((sum, r) => sum + Number(r.valorEstimado || 0), 0);
    const onTimeRate = 95.5; // Mock
    const savings = totalValue * 0.12; // Mock 12% savings

    res.json({
      totalRequests,
      totalValue,
      onTimeRate,
      savings
    });
  });

  // === CORREIOS INTEGRATION ===
  app.get("/api/integrations/correios/status", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const status = getIntegrationStatus();
      res.json(status);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/integrations/correios/rastro/:codigo", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const { codigo } = req.params;
      const resultado = await rastrearObjeto(codigo);
      res.json(resultado);
    } catch (e: any) {
      if (e instanceof CorreiosError) {
        res.status(e.statusCode).json({ error: e.message });
      } else {
        res.status(500).json({ error: "Erro interno ao processar rastreamento." });
      }
    }
  });

  app.get("/api/integrations/logs", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const tipoApi = req.query.tipo as string | undefined;
      const limit = req.query.limit ? Number(req.query.limit) : 50;
      const logs = await storage.getIntegrationLogs(tipoApi, limit);
      res.json(logs);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // === LOGÍSTICA REVERSA ===
  app.get("/api/logistica-reversa/status", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const status = logisticaReversa.getLogisticaReversaStatus();
      res.json(status);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/logistica-reversa/pedidos", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const pedidos = await storage.getLogisticaReversaPedidos();
      res.json(pedidos);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/logistica-reversa/pedido/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const pedido = await storage.getLogisticaReversaPedido(Number(req.params.id));
      if (!pedido) return res.status(404).json({ error: "Pedido não encontrado" });
      res.json(pedido);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/logistica-reversa/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const stats = await storage.getLogisticaReversaStats();
      res.json(stats);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/logistica-reversa/solicitar", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const validationResult = solicitarLRSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Dados inválidos", 
          details: validationResult.error.errors 
        });
      }
      const { tipo, codigoServico, remetente, destinatario, objeto, observacao } = validationResult.data;
      
      const idCliente = `LR-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      const resultado = await logisticaReversa.solicitarPostagemReversa({
        codigo_servico: codigoServico || logisticaReversa.CODIGOS_SERVICO.PAC_REVERSA,
        destinatario: {
          nome: destinatario.nome,
          logradouro: destinatario.logradouro,
          numero: destinatario.numero,
          complemento: destinatario.complemento,
          bairro: destinatario.bairro,
          cep: destinatario.cep.replace(/\D/g, ""),
          cidade: destinatario.cidade,
          uf: destinatario.uf,
          ddd: destinatario.ddd,
          telefone: destinatario.telefone,
          email: destinatario.email,
        },
        coletas_solicitadas: [{
          tipo: tipo || "A",
          id_cliente: idCliente,
          remetente: {
            nome: remetente.nome,
            logradouro: remetente.logradouro,
            numero: remetente.numero,
            complemento: remetente.complemento,
            bairro: remetente.bairro,
            cep: remetente.cep.replace(/\D/g, ""),
            cidade: remetente.cidade,
            uf: remetente.uf,
            ddd: remetente.ddd,
            telefone: remetente.telefone,
            email: remetente.email,
          },
          objeto: objeto ? {
            id_cliente: idCliente,
            descricao: objeto.descricao,
            numero: objeto.numero,
          } : undefined,
        }],
      });

      const solicitacao = resultado.resultado_solicitacao?.[0];
      
      const pedido = await storage.createLogisticaReversaPedido({
        numeroPedido: solicitacao?.numero_coleta || solicitacao?.numero_etiqueta || null,
        numeroEtiqueta: solicitacao?.numero_etiqueta || null,
        tipo: tipo || "A",
        codigoServico: codigoServico || logisticaReversa.CODIGOS_SERVICO.PAC_REVERSA,
        status: "solicitado",
        idCliente,
        prazo: solicitacao?.prazo || null,
        remetenteNome: remetente.nome,
        remetenteCep: remetente.cep,
        remetenteEndereco: `${remetente.logradouro}, ${remetente.numero}`,
        remetenteCidade: remetente.cidade,
        remetenteUf: remetente.uf,
        remetenteEmail: remetente.email,
        remetenteTelefone: remetente.telefone,
        destinatarioNome: destinatario.nome,
        destinatarioCep: destinatario.cep,
        destinatarioEndereco: `${destinatario.logradouro}, ${destinatario.numero}`,
        destinatarioCidade: destinatario.cidade,
        destinatarioUf: destinatario.uf,
        observacao,
      });

      await storage.addLogisticaReversaEvento({
        pedidoId: pedido.id,
        status: "solicitado",
        descricao: `Pedido criado - ${solicitacao?.status_objeto || "Aguardando processamento"}`,
      });

      res.status(201).json({ pedido, correios: resultado });
    } catch (e: any) {
      console.error("[LR] Erro ao solicitar:", e.message);
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/logistica-reversa/solicitar-massa", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const validationResult = solicitarMassaSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Dados inválidos", 
          details: validationResult.error.errors 
        });
      }
      const { solicitacoes, destinatario, codigoServico } = validationResult.data;

      const coletas = solicitacoes.map((s: any, index: number) => {
        const idCliente = `LR-MASSA-${Date.now()}-${index}`;
        return {
          tipo: s.tipo || "A",
          id_cliente: idCliente,
          remetente: {
            nome: s.remetente.nome,
            logradouro: s.remetente.logradouro,
            numero: s.remetente.numero,
            complemento: s.remetente.complemento,
            bairro: s.remetente.bairro,
            cep: s.remetente.cep.replace(/\D/g, ""),
            cidade: s.remetente.cidade,
            uf: s.remetente.uf,
            ddd: s.remetente.ddd,
            telefone: s.remetente.telefone,
            email: s.remetente.email,
          },
        };
      });

      const resultado = await logisticaReversa.solicitarPostagemReversa({
        codigo_servico: codigoServico || logisticaReversa.CODIGOS_SERVICO.PAC_REVERSA,
        destinatario: {
          nome: destinatario.nome,
          logradouro: destinatario.logradouro,
          numero: destinatario.numero,
          complemento: destinatario.complemento,
          bairro: destinatario.bairro,
          cep: destinatario.cep.replace(/\D/g, ""),
          cidade: destinatario.cidade,
          uf: destinatario.uf,
          ddd: destinatario.ddd,
          telefone: destinatario.telefone,
          email: destinatario.email,
        },
        coletas_solicitadas: coletas,
      });

      const pedidosCriados = [];
      for (const solicitacao of resultado.resultado_solicitacao || []) {
        const pedido = await storage.createLogisticaReversaPedido({
          numeroPedido: solicitacao.numero_coleta || solicitacao.numero_etiqueta || null,
          numeroEtiqueta: solicitacao.numero_etiqueta || null,
          tipo: "A",
          codigoServico: codigoServico || logisticaReversa.CODIGOS_SERVICO.PAC_REVERSA,
          status: "solicitado",
          idCliente: solicitacao.id_cliente,
          prazo: solicitacao.prazo || null,
          destinatarioNome: destinatario.nome,
          destinatarioCep: destinatario.cep,
          destinatarioEndereco: `${destinatario.logradouro}, ${destinatario.numero}`,
          destinatarioCidade: destinatario.cidade,
          destinatarioUf: destinatario.uf,
        });
        pedidosCriados.push(pedido);
      }

      res.status(201).json({ 
        sucesso: pedidosCriados.length,
        total: solicitacoes.length,
        pedidos: pedidosCriados,
        correios: resultado,
      });
    } catch (e: any) {
      console.error("[LR] Erro ao solicitar em massa:", e.message);
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/logistica-reversa/cancelar/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const pedido = await storage.getLogisticaReversaPedido(Number(req.params.id));
      if (!pedido) return res.status(404).json({ error: "Pedido não encontrado" });
      if (!pedido.numeroPedido) return res.status(400).json({ error: "Pedido sem número de coleta" });

      const resultado = await logisticaReversa.cancelarPedido(pedido.numeroPedido);
      
      const pedidoAtualizado = await storage.updateLogisticaReversaPedido(pedido.id, {
        status: "cancelado",
      });

      await storage.addLogisticaReversaEvento({
        pedidoId: pedido.id,
        status: "cancelado",
        descricao: `Cancelado - ${resultado.status_pedido}`,
      });

      res.json({ pedido: pedidoAtualizado, correios: resultado });
    } catch (e: any) {
      console.error("[LR] Erro ao cancelar:", e.message);
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/logistica-reversa/revalidar/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const pedido = await storage.getLogisticaReversaPedido(Number(req.params.id));
      if (!pedido) return res.status(404).json({ error: "Pedido não encontrado" });
      if (!pedido.numeroPedido) return res.status(400).json({ error: "Pedido sem número de coleta" });

      const resultado = await logisticaReversa.revalidarPrazo(pedido.numeroPedido);
      
      const pedidoAtualizado = await storage.updateLogisticaReversaPedido(pedido.id, {
        prazo: resultado.prazo || resultado.data_validade,
      });

      await storage.addLogisticaReversaEvento({
        pedidoId: pedido.id,
        status: "revalidado",
        descricao: `Prazo revalidado até ${resultado.data_validade || resultado.prazo}`,
      });

      res.json({ pedido: pedidoAtualizado, correios: resultado });
    } catch (e: any) {
      console.error("[LR] Erro ao revalidar:", e.message);
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/logistica-reversa/atualizar-status/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const pedido = await storage.getLogisticaReversaPedido(Number(req.params.id));
      if (!pedido) return res.status(404).json({ error: "Pedido não encontrado" });
      if (!pedido.numeroPedido) return res.status(400).json({ error: "Pedido sem número de coleta" });

      const resultado = await logisticaReversa.acompanharPedido(pedido.numeroPedido);
      
      let novoStatus = pedido.status;
      if (resultado.status_pedido) {
        const statusMap: Record<string, string> = {
          "Solicitado": "solicitado",
          "Autorizado": "aguardando_postagem",
          "Em Trânsito": "em_transito",
          "Coletado": "coletado",
          "Entregue": "entregue",
          "Cancelado": "cancelado",
        };
        novoStatus = statusMap[resultado.status_pedido] || pedido.status;
      }
      
      const pedidoAtualizado = await storage.updateLogisticaReversaPedido(pedido.id, {
        status: novoStatus,
        numeroEtiqueta: resultado.objeto?.numero_etiqueta || pedido.numeroEtiqueta,
      });

      await storage.addLogisticaReversaEvento({
        pedidoId: pedido.id,
        status: novoStatus,
        descricao: `Status atualizado: ${resultado.status_pedido}`,
      });

      res.json({ pedido: pedidoAtualizado, correios: resultado });
    } catch (e: any) {
      console.error("[LR] Erro ao atualizar status:", e.message);
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/logistica-reversa/consulta/:numero", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const { numero } = req.params;
      const pedido = await storage.getLogisticaReversaPedidoByNumero(numero);
      if (!pedido) {
        return res.status(404).json({ error: "Pedido não encontrado" });
      }
      res.json(pedido);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/logistica-reversa/servicos", async (req, res) => {
    res.json({
      servicos: [
        { codigo: logisticaReversa.CODIGOS_SERVICO.PAC_REVERSA, nome: "PAC Reversa" },
        { codigo: logisticaReversa.CODIGOS_SERVICO.SEDEX_REVERSA, nome: "SEDEX Reversa" },
        { codigo: logisticaReversa.CODIGOS_SERVICO.SEDEX_10_REVERSA, nome: "SEDEX 10 Reversa" },
        { codigo: logisticaReversa.CODIGOS_SERVICO.SEDEX_12_REVERSA, nome: "SEDEX 12 Reversa" },
      ],
      tipos: [
        { codigo: logisticaReversa.TIPOS_COLETA.AUTORIZACAO_POSTAGEM, nome: "Autorização de Postagem em Agência" },
        { codigo: logisticaReversa.TIPOS_COLETA.COLETA_DOMICILIAR, nome: "Coleta Domiciliar" },
        { codigo: logisticaReversa.TIPOS_COLETA.COLETA_SIMULTANEA, nome: "Coleta Simultânea" },
      ],
      embalagens: [
        { codigo: "envelope_bolha_2", nome: "Envelope Bolha 2", dimensoes: "C 28 x L 20 cm", peso: 0.1 },
        { codigo: "caixa_p", nome: "Caixa Encomenda P", dimensoes: "C 24 x L 16 x A 8 cm", peso: 0.3 },
        { codigo: "caixa_m", nome: "Caixa Encomenda M", dimensoes: "C 30 x L 22 x A 13 cm", peso: 0.5 },
        { codigo: "caixa_g", nome: "Caixa Encomenda G", dimensoes: "C 36 x L 28 x A 28 cm", peso: 0.8 },
        { codigo: "envelope_bolha_grande", nome: "Envelope Bolha Grande", dimensoes: "C 28 x L 40 cm", peso: 0.2, codigoCorreios: "765000911" },
        { codigo: "caixa_gg", nome: "Caixa Encomenda GG", dimensoes: "C 52 x L 40 x A 32 cm", peso: 1.2, codigoCorreios: "116601728" },
      ],
    });
  });

  app.get("/api/cep/:cep", async (req, res) => {
    try {
      const { cep } = req.params;
      const cepLimpo = cep.replace(/\D/g, "");
      
      if (cepLimpo.length !== 8) {
        return res.status(400).json({ error: "CEP deve ter 8 dígitos" });
      }
      
      const response = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);
      const data = await response.json();
      
      if (data.erro) {
        return res.status(404).json({ error: "CEP não encontrado" });
      }
      
      res.json({
        cep: data.cep,
        logradouro: data.logradouro,
        complemento: data.complemento || "",
        bairro: data.bairro,
        cidade: data.localidade,
        uf: data.uf,
        ibge: data.ibge,
        ddd: data.ddd || "",
      });
    } catch (e: any) {
      res.status(500).json({ error: "Erro ao consultar CEP" });
    }
  });

  app.get("/api/logistica-reversa/modelo-xlsx", async (req, res) => {
    try {
      const XLSX = await import("xlsx");
      
      const dados = [
        {
          nome: "João Silva",
          cep: "01310100",
          logradouro: "Av Paulista",
          numero: "1000",
          complemento: "Sala 101",
          bairro: "Bela Vista",
          cidade: "São Paulo",
          uf: "SP",
          ddd: "11",
          telefone: "999999999",
          email: "joao@email.com"
        },
        {
          nome: "Maria Santos",
          cep: "22041080",
          logradouro: "Av Atlântica",
          numero: "500",
          complemento: "Apto 302",
          bairro: "Copacabana",
          cidade: "Rio de Janeiro",
          uf: "RJ",
          ddd: "21",
          telefone: "988888888",
          email: "maria@email.com"
        }
      ];
      
      const worksheet = XLSX.utils.json_to_sheet(dados);
      
      worksheet["!cols"] = [
        { wch: 25 },
        { wch: 12 },
        { wch: 30 },
        { wch: 10 },
        { wch: 20 },
        { wch: 20 },
        { wch: 20 },
        { wch: 5 },
        { wch: 5 },
        { wch: 15 },
        { wch: 25 }
      ];
      
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Coletas");
      
      const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
      
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", "attachment; filename=modelo_coleta_reversa.xlsx");
      res.send(buffer);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  return httpServer;
}
