import { storage } from "./storage";
import { hashPassword } from "./auth";
import { insertUserSchema, insertOperatorSchema } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  // 1. Create Users
  const adminEmail = "admin@logistica.com";
  const existingAdmin = await storage.getUserByUsername(adminEmail);
  
  if (!existingAdmin) {
    console.log("Creating admin user...");
    const adminPassword = await hashPassword("admin123");
    await storage.createUser({
      name: "Administrador",
      email: adminEmail,
      password: adminPassword,
      role: "admin",
      active: true
    });
  }

  const clientEmail = "cliente@empresa.com";
  const existingClient = await storage.getUserByUsername(clientEmail);
  
  if (!existingClient) {
    console.log("Creating client user...");
    const clientPassword = await hashPassword("cliente123");
    await storage.createUser({
      name: "Empresa Cliente LTDA",
      email: clientEmail,
      password: clientPassword,
      role: "client",
      active: true
    });
  }

  // 2. Create Operators
  const existingOperators = await storage.getOperators();
  if (existingOperators.length === 0) {
    console.log("Creating logistic operators...");
    
    const op1 = await storage.createOperator({
      razaoSocial: "RapidCargo Logística",
      cnpj: "12.345.678/0001-90",
      email: "contato@rapidcargo.com",
      telefone: "(11) 99999-0001",
      contato: "João Silva",
      ativo: true
    });

    const op2 = await storage.createOperator({
      razaoSocial: "TransNacional Transportes",
      cnpj: "98.765.432/0001-10",
      email: "comercial@transnacional.com",
      telefone: "(21) 98888-0002",
      contato: "Maria Oliveira",
      ativo: true
    });

    // Add Coverage
    await storage.addCoverage({ operatorId: op1.id, uf: "SP", prazoDias: 1 });
    await storage.addCoverage({ operatorId: op1.id, uf: "RJ", prazoDias: 2 });
    await storage.addCoverage({ operatorId: op2.id, uf: "SP", prazoDias: 2 });
    await storage.addCoverage({ operatorId: op2.id, uf: "RJ", prazoDias: 1 });
    await storage.addCoverage({ operatorId: op2.id, uf: "MG", prazoDias: 3 });

    // Add Prices
    await storage.addPrice({ operatorId: op1.id, pesoMin: "0", pesoMax: "5", valorKg: "15.00", cubagemMax: "0.5" });
    await storage.addPrice({ operatorId: op1.id, pesoMin: "5", pesoMax: "20", valorKg: "12.00", cubagemMax: "1.0" });
    await storage.addPrice({ operatorId: op2.id, pesoMin: "0", pesoMax: "10", valorKg: "14.50", cubagemMax: "0.8" });

    // 3. Create Requests
    const client = await storage.getUserByUsername(clientEmail);
    if (client) {
      console.log("Creating sample requests...");
      
      const req1 = await storage.createRequest({
        clientId: client.id,
        origem: "São Paulo, SP",
        destino: "Rio de Janeiro, RJ",
        peso: "10.5",
        cubagem: "0.3",
        status: "collected",
        recommendedOperatorId: op1.id,
        valorEstimado: "150.00",
        prazoEstimado: 2
      });

      await storage.addTracking({
        requestId: req1.id,
        status: "Coletado",
        localizacao: "São Paulo, SP",
        observacao: "Mercadoria coletada no CD"
      });

      await storage.addTracking({
        requestId: req1.id,
        status: "Em Trânsito",
        localizacao: "Via Dutra",
        observacao: "Caminhão em rota"
      });

      await storage.createRequest({
        clientId: client.id,
        origem: "Belo Horizonte, MG",
        destino: "São Paulo, SP",
        peso: "5.0",
        cubagem: "0.1",
        status: "pending",
        recommendedOperatorId: op2.id,
        valorEstimado: "85.00",
        prazoEstimado: 3
      });
    }
  }

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});
