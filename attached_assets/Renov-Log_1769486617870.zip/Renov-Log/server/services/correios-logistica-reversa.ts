import * as soap from "soap";
import { storage } from "../storage";

// URLs dos Correios - Logística Reversa
// Produção: Requer habilitação do serviço LR no contrato junto ao comercial dos Correios
const WSDL_PRODUCAO = "https://cws.correios.com.br/logisticaReversaWS/logisticaReversaService/logisticaReversaWS?wsdl";
// Homologação: Usar para testes com credenciais empresacws/123456
const WSDL_HOMOLOGACAO = "https://apphom.correios.com.br/logisticaReversaWS/logisticaReversaService/logisticaReversaWS?wsdl";

// Credenciais de homologação para testes (conforme manual Correios)
const HOMOLOGACAO_USUARIO = "empresacws";
const HOMOLOGACAO_SENHA = "123456";
const HOMOLOGACAO_COD_ADM = "17000190";
const HOMOLOGACAO_CARTAO = "0011111111";

// Usar homologação para testes enquanto produção não está liberada
const USE_PRODUCAO = process.env.CORREIOS_LR_PRODUCAO === "true";
const WSDL_URL = USE_PRODUCAO ? WSDL_PRODUCAO : WSDL_HOMOLOGACAO;

let MODO_SIMULACAO = process.env.CORREIOS_LR_SIMULACAO === "true" || !process.env.CORREIOS_LR_USUARIO;

let soapClient: soap.Client | null = null;
let soapClientFailed = false;

interface Destinatario {
  nome: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cep: string;
  cidade: string;
  uf: string;
  ddd?: string;
  telefone?: string;
  email?: string;
}

interface Remetente {
  nome: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cep: string;
  cidade: string;
  uf: string;
  ddd?: string;
  telefone?: string;
  email?: string;
  identificacao?: string;
}

interface ObjetoPostal {
  id_cliente: string;
  descricao?: string;
  numero?: string;
  ar?: string;
  valor_declarado?: string;
}

interface ColetaSolicitada {
  tipo: "A" | "C" | "CA";
  id_cliente: string;
  ag?: string;
  cartao?: string;
  servico_adicional?: string[];
  remetente: Remetente;
  objeto?: ObjetoPostal;
}

interface SolicitarPostagemReversaParams {
  codigo_servico: string;
  destinatario: Destinatario;
  coletas_solicitadas: ColetaSolicitada[];
}

interface ResultadoSolicitacao {
  id_cliente: string;
  numero_coleta?: string;
  numero_etiqueta?: string;
  status_objeto: string;
  prazo?: string;
  data_solicitacao?: string;
  hora_solicitacao?: string;
}

interface SolicitarPostagemReversaResponse {
  resultado_solicitacao: ResultadoSolicitacao[];
  cod_erro?: string;
  msg_erro?: string;
}

interface AcompanharPedidoResponse {
  numero_pedido: string;
  controle_cliente?: string;
  status_pedido: string;
  data_pedido?: string;
  hora_pedido?: string;
  data_ultima_atualizacao?: string;
  hora_ultima_atualizacao?: string;
  objeto?: {
    numero_etiqueta?: string;
    eventos?: {
      evento: {
        status: string;
        data: string;
        hora: string;
        descricao: string;
      }[];
    };
  };
  cod_erro?: string;
  msg_erro?: string;
}

interface CancelarPedidoResponse {
  numero_pedido: string;
  status_pedido: string;
  data_cancelamento?: string;
  hora_cancelamento?: string;
  cod_erro?: string;
  msg_erro?: string;
}

function getCredentials() {
  // Se em produção, usa credenciais do ambiente
  // Se em homologação, usa credenciais de teste dos Correios
  if (USE_PRODUCAO) {
    const usuario = process.env.CORREIOS_LR_USUARIO;
    const senha = process.env.CORREIOS_LR_SENHA;
    const codAdministrativo = process.env.CORREIOS_LR_COD_ADMINISTRATIVO;
    const cartao = process.env.CORREIOS_CARTAO_POSTAGEM;

    if (!usuario || !senha || !codAdministrativo) {
      throw new Error("Credenciais de Logística Reversa não configuradas. Configure CORREIOS_LR_USUARIO, CORREIOS_LR_SENHA e CORREIOS_LR_COD_ADMINISTRATIVO.");
    }

    return { usuario, senha, codAdministrativo, cartao };
  } else {
    // Credenciais de homologação (teste) dos Correios
    console.log("[Correios LR] Usando credenciais de HOMOLOGAÇÃO para testes");
    return { 
      usuario: HOMOLOGACAO_USUARIO, 
      senha: HOMOLOGACAO_SENHA, 
      codAdministrativo: HOMOLOGACAO_COD_ADM, 
      cartao: HOMOLOGACAO_CARTAO 
    };
  }
}

async function getClient(): Promise<soap.Client | null> {
  if (soapClientFailed && MODO_SIMULACAO) {
    return null;
  }
  
  if (soapClient) {
    return soapClient;
  }

  // Usar credenciais de homologação ou produção conforme configuração
  const usuario = USE_PRODUCAO 
    ? (process.env.CORREIOS_LR_USUARIO || "") 
    : HOMOLOGACAO_USUARIO;
  const senha = USE_PRODUCAO 
    ? (process.env.CORREIOS_LR_SENHA || "") 
    : HOMOLOGACAO_SENHA;

  return new Promise((resolve) => {
    // O WSDL dos Correios exige autenticação Basic HTTP para acessar o próprio WSDL
    // As credenciais devem ser passadas tanto para acessar o WSDL quanto nas chamadas SOAP
    const options: soap.IOptions = { 
      wsdl_options: { 
        timeout: 30000,
        // Autenticação Basic para acessar o WSDL
        auth: {
          username: usuario,
          password: senha
        }
      },
      forceSoap12Headers: false
    };

    console.log("[Correios LR] Ambiente:", USE_PRODUCAO ? "PRODUÇÃO" : "HOMOLOGAÇÃO");
    console.log("[Correios LR] Tentando conectar ao WSDL:", WSDL_URL);
    console.log("[Correios LR] Usuário:", usuario);

    soap.createClient(WSDL_URL, options, (err, client) => {
      if (err) {
        console.error("[Correios LR] Erro ao criar cliente SOAP:", err.message);
        console.error("[Correios LR] URL do WSDL:", WSDL_URL);
        
        // Verifica se é erro de autenticação (401) ou rede
        const isAuthError = err.message.includes("401") || err.message.includes("Unauthorized");
        
        if (isAuthError) {
          console.log("[Correios LR] Erro 401 - Credenciais inválidas ou expiradas");
          console.log("[Correios LR] NOTA: Os Correios agora exigem 'Código de Acesso' gerado no portal CWS (válido por 24h)");
          console.log("[Correios LR] Ativando MODO SIMULAÇÃO para demonstração");
        }
        
        // Ativa modo simulação em caso de falha de conexão ou autenticação
        console.log("[Correios LR] Ativando modo simulação devido a falha de conexão");
        soapClientFailed = true;
        MODO_SIMULACAO = true;
        resolve(null);
        return;
      }

      // Configura autenticação Basic para todas as chamadas SOAP subsequentes
      if (usuario && senha) {
        client.setSecurity(new soap.BasicAuthSecurity(usuario, senha));
        console.log("[Correios LR] Autenticação Basic configurada para chamadas SOAP");
      }

      soapClient = client;
      console.log("[Correios LR] Cliente SOAP criado com sucesso");
      console.log("[Correios LR] Métodos disponíveis:", Object.keys(client.describe()));
      resolve(client);
    });
  });
}

async function logIntegration(endpoint: string, requestData: any, responseData: any, statusCode: number) {
  try {
    await storage.addIntegrationLog({
      tipoApi: "correios_lr",
      endpoint,
      requestData: { ...requestData, senha: "***" },
      responseData,
      statusCode,
    });
  } catch (e) {
    console.error("[Correios LR] Erro ao salvar log:", e);
  }
}

function gerarRespostaSimulada(params: SolicitarPostagemReversaParams): SolicitarPostagemReversaResponse {
  console.log("[Correios LR] Modo simulação ativado - gerando resposta simulada");
  const resultados = params.coletas_solicitadas.map((coleta, index) => {
    const numeroPedido = `SIM${Date.now()}${index}`;
    const numeroEtiqueta = `LR${Math.random().toString(36).substr(2, 9).toUpperCase()}BR`;
    const prazo = new Date();
    prazo.setDate(prazo.getDate() + 7);
    
    return {
      id_cliente: coleta.id_cliente,
      numero_coleta: numeroPedido,
      numero_etiqueta: numeroEtiqueta,
      status_objeto: "Solicitado",
      prazo: prazo.toISOString().split('T')[0],
      data_solicitacao: new Date().toISOString().split('T')[0],
      hora_solicitacao: new Date().toTimeString().split(' ')[0],
    };
  });
  
  return {
    resultado_solicitacao: resultados,
    cod_erro: "0",
    msg_erro: "Simulação - Solicitação registrada com sucesso",
  };
}

export async function solicitarPostagemReversa(params: SolicitarPostagemReversaParams): Promise<SolicitarPostagemReversaResponse> {
  // Tenta conectar primeiro para verificar se deve usar simulação
  const client = await getClient();
  
  if (MODO_SIMULACAO) {
    const resposta = gerarRespostaSimulada(params);
    await logIntegration("solicitarPostagemReversa_simulado", params, { ...resposta, modo: "simulacao" }, 200);
    return resposta;
  }

  if (!client) {
    throw new Error(
      "Falha de autenticação com Correios (401). " +
      "SOLUÇÃO: 1) Acesse https://cws.correios.com.br com seu login Meu Correios. " +
      "2) Vá em 'Gestão de acesso a APIs' e gere um novo Código de Acesso. " +
      "3) Atualize CORREIOS_LR_USUARIO com seu usuário Meu Correios e CORREIOS_LR_SENHA com o Código de Acesso gerado. " +
      "Nota: O código de acesso expira em 24 horas."
    );
  }

  const creds = getCredentials();

  // O WSDL define que a autenticação é via HTTP Basic (setSecurity), não no corpo do SOAP
  // Conforme WSDL, coletas_solicitadas espera lista de objetos com: remetente, tipo, id_cliente, etc.
  // Não usar wrapper 'coleta' - passar array diretamente
  const coletas = params.coletas_solicitadas.map(coleta => ({
    tipo: coleta.tipo,
    id_cliente: coleta.id_cliente,
    ag: coleta.ag || "",
    cartao: coleta.cartao || creds.cartao || "",
    servico_adicional: coleta.servico_adicional || [],
    remetente: coleta.remetente,
    obj_col: coleta.objeto ? [coleta.objeto] : [],
  }));

  const requestBody = {
    codAdministrativo: creds.codAdministrativo,
    cartao: creds.cartao || "",
    codigo_servico: params.codigo_servico,
    destinatario: params.destinatario,
    coletas_solicitadas: coletas,
  };

  return new Promise((resolve, reject) => {
    client.solicitarPostagemReversa(requestBody, async (err: any, result: any) => {
      if (err) {
        console.error("[Correios LR] Erro na solicitação:", err.message);
        await logIntegration("solicitarPostagemReversa", requestBody, { error: err.message }, 500);
        reject(new Error(err.message || "Erro ao solicitar postagem reversa"));
        return;
      }

      const response = result?.return || result;
      await logIntegration("solicitarPostagemReversa", requestBody, response, response?.cod_erro ? 400 : 200);

      if (response?.cod_erro && response.cod_erro !== "0") {
        reject(new Error(response.msg_erro || `Erro ${response.cod_erro}`));
        return;
      }

      resolve({
        resultado_solicitacao: Array.isArray(response.resultado_solicitacao) 
          ? response.resultado_solicitacao 
          : [response.resultado_solicitacao].filter(Boolean),
        cod_erro: response.cod_erro,
        msg_erro: response.msg_erro,
      });
    });
  });
}

export async function cancelarPedido(numeroPedido: string, tipo: string = "A"): Promise<CancelarPedidoResponse> {
  const client = await getClient();
  
  if (MODO_SIMULACAO || !client) {
    console.log("[Correios LR] Modo simulação - cancelamento simulado");
    const resposta = {
      numero_pedido: numeroPedido,
      status_pedido: "Cancelado",
      data_cancelamento: new Date().toISOString().split('T')[0],
      hora_cancelamento: new Date().toTimeString().split(' ')[0],
    };
    await logIntegration("cancelarPedido_simulado", { numeroPedido, tipo }, resposta, 200);
    return resposta;
  }

  const creds = getCredentials();

  // Autenticação via HTTP Basic (setSecurity), não no corpo do SOAP
  const requestBody = {
    codAdministrativo: creds.codAdministrativo,
    numeroPedido,
    tipo,
  };

  return new Promise((resolve, reject) => {
    client.cancelarPedido(requestBody, async (err: any, result: any) => {
      if (err) {
        console.error("[Correios LR] Erro ao cancelar:", err.message);
        await logIntegration("cancelarPedido", requestBody, { error: err.message }, 500);
        reject(new Error(err.message || "Erro ao cancelar pedido"));
        return;
      }

      const response = result?.return || result;
      await logIntegration("cancelarPedido", requestBody, response, response?.cod_erro ? 400 : 200);

      if (response?.cod_erro && response.cod_erro !== "0") {
        reject(new Error(response.msg_erro || `Erro ${response.cod_erro}`));
        return;
      }

      resolve({
        numero_pedido: response.numero_pedido,
        status_pedido: response.status_pedido,
        data_cancelamento: response.data_cancelamento,
        hora_cancelamento: response.hora_cancelamento,
        cod_erro: response.cod_erro,
        msg_erro: response.msg_erro,
      });
    });
  });
}

export async function acompanharPedido(numeroPedido: string, tipoHistorico: string = "H"): Promise<AcompanharPedidoResponse> {
  const client = await getClient();
  
  if (MODO_SIMULACAO || !client) {
    console.log("[Correios LR] Modo simulação - acompanhamento simulado");
    const resposta = {
      numero_pedido: numeroPedido,
      status_pedido: "Solicitado",
      data_pedido: new Date().toISOString().split('T')[0],
      hora_pedido: new Date().toTimeString().split(' ')[0],
    };
    await logIntegration("acompanharPedido_simulado", { numeroPedido }, resposta, 200);
    return resposta;
  }

  const creds = getCredentials();

  // Autenticação via HTTP Basic (setSecurity), não no corpo do SOAP
  const requestBody = {
    codAdministrativo: creds.codAdministrativo,
    numeroPedido,
    tipoHistorico,
  };

  return new Promise((resolve, reject) => {
    client.acompanharPedido(requestBody, async (err: any, result: any) => {
      if (err) {
        console.error("[Correios LR] Erro ao acompanhar:", err.message);
        await logIntegration("acompanharPedido", requestBody, { error: err.message }, 500);
        reject(new Error(err.message || "Erro ao acompanhar pedido"));
        return;
      }

      const response = result?.return || result;
      await logIntegration("acompanharPedido", requestBody, response, response?.cod_erro ? 400 : 200);

      if (response?.cod_erro && response.cod_erro !== "0") {
        reject(new Error(response.msg_erro || `Erro ${response.cod_erro}`));
        return;
      }

      resolve({
        numero_pedido: response.numero_pedido,
        controle_cliente: response.controle_cliente,
        status_pedido: response.status_pedido,
        data_pedido: response.data_pedido,
        hora_pedido: response.hora_pedido,
        data_ultima_atualizacao: response.data_ultima_atualizacao,
        hora_ultima_atualizacao: response.hora_ultima_atualizacao,
        objeto: response.objeto,
        cod_erro: response.cod_erro,
        msg_erro: response.msg_erro,
      });
    });
  });
}

export async function acompanharPedidoPorData(dataInicial: string, dataFinal: string): Promise<AcompanharPedidoResponse[]> {
  const client = await getClient();
  
  if (MODO_SIMULACAO || !client) {
    console.log("[Correios LR] Modo simulação - consulta por data simulada");
    await logIntegration("acompanharPedidoPorData_simulado", { dataInicial, dataFinal }, [], 200);
    return [];
  }

  const creds = getCredentials();

  // Autenticação via HTTP Basic (setSecurity), não no corpo do SOAP
  const requestBody = {
    codAdministrativo: creds.codAdministrativo,
    dataInicial,
    dataFinal,
  };

  return new Promise((resolve, reject) => {
    client.acompanharPedidoPorData(requestBody, async (err: any, result: any) => {
      if (err) {
        console.error("[Correios LR] Erro na consulta por data:", err.message);
        await logIntegration("acompanharPedidoPorData", requestBody, { error: err.message }, 500);
        reject(new Error(err.message || "Erro ao consultar pedidos por data"));
        return;
      }

      const response = result?.return || result;
      await logIntegration("acompanharPedidoPorData", requestBody, response, response?.cod_erro ? 400 : 200);

      if (response?.cod_erro && response.cod_erro !== "0") {
        reject(new Error(response.msg_erro || `Erro ${response.cod_erro}`));
        return;
      }

      const coletas = Array.isArray(response.coleta) ? response.coleta : [response.coleta].filter(Boolean);
      resolve(coletas);
    });
  });
}

export async function revalidarPrazo(numeroPedido: string): Promise<{ prazo?: string; data_validade?: string }> {
  const client = await getClient();
  
  if (MODO_SIMULACAO || !client) {
    console.log("[Correios LR] Modo simulação - revalidação simulada");
    const prazo = new Date();
    prazo.setDate(prazo.getDate() + 7);
    const resposta = {
      prazo: prazo.toISOString().split('T')[0],
      data_validade: prazo.toISOString().split('T')[0],
    };
    await logIntegration("revalidarPrazo_simulado", { numeroPedido }, resposta, 200);
    return resposta;
  }

  const creds = getCredentials();

  // Autenticação via HTTP Basic (setSecurity), não no corpo do SOAP
  const requestBody = {
    codAdministrativo: creds.codAdministrativo,
    numeroPedido,
  };

  return new Promise((resolve, reject) => {
    client.revalidarPrazoAutorizacaoPostagem(requestBody, async (err: any, result: any) => {
      if (err) {
        console.error("[Correios LR] Erro ao revalidar prazo:", err.message);
        await logIntegration("revalidarPrazoAutorizacaoPostagem", requestBody, { error: err.message }, 500);
        reject(new Error(err.message || "Erro ao revalidar prazo"));
        return;
      }

      const response = result?.return || result;
      await logIntegration("revalidarPrazoAutorizacaoPostagem", requestBody, response, response?.cod_erro ? 400 : 200);

      if (response?.cod_erro && response.cod_erro !== "0") {
        reject(new Error(response.msg_erro || `Erro ${response.cod_erro}`));
        return;
      }

      resolve({
        prazo: response.prazo,
        data_validade: response.data_validade,
      });
    });
  });
}

export async function solicitarRange(quantidade: number): Promise<{ faixa_inicial: string; faixa_final: string }> {
  const client = await getClient();
  
  if (MODO_SIMULACAO || !client) {
    console.log("[Correios LR] Modo simulação - range simulado");
    const base = Date.now().toString().slice(-8);
    const resposta = {
      faixa_inicial: `LR${base}000BR`,
      faixa_final: `LR${base}${String(quantidade).padStart(3, '0')}BR`,
    };
    await logIntegration("solicitarRange_simulado", { quantidade }, resposta, 200);
    return resposta;
  }

  const creds = getCredentials();

  // Autenticação via HTTP Basic (setSecurity), não no corpo do SOAP
  const requestBody = {
    codAdministrativo: creds.codAdministrativo,
    quantidade,
  };

  return new Promise((resolve, reject) => {
    client.solicitarRange(requestBody, async (err: any, result: any) => {
      if (err) {
        console.error("[Correios LR] Erro ao solicitar range:", err.message);
        await logIntegration("solicitarRange", requestBody, { error: err.message }, 500);
        reject(new Error(err.message || "Erro ao solicitar range"));
        return;
      }

      const response = result?.return || result;
      await logIntegration("solicitarRange", requestBody, response, response?.cod_erro ? 400 : 200);

      if (response?.cod_erro && response.cod_erro !== "0") {
        reject(new Error(response.msg_erro || `Erro ${response.cod_erro}`));
        return;
      }

      resolve({
        faixa_inicial: response.faixa_inicial,
        faixa_final: response.faixa_final,
      });
    });
  });
}

export function getLogisticaReversaStatus(): { configured: boolean; wsdlUrl: string; ambiente: string } {
  const hasCredentials = !!(
    process.env.CORREIOS_LR_USUARIO &&
    process.env.CORREIOS_LR_SENHA &&
    process.env.CORREIOS_LR_COD_ADMINISTRATIVO
  );

  return {
    configured: hasCredentials,
    wsdlUrl: WSDL_URL,
    ambiente: USE_PRODUCAO ? "Produção" : "Homologação",
  };
}

export const CODIGOS_SERVICO = {
  PAC_REVERSA: "41076",
  SEDEX_REVERSA: "40010",
  SEDEX_10_REVERSA: "40215",
  SEDEX_12_REVERSA: "40290",
};

export const TIPOS_COLETA = {
  AUTORIZACAO_POSTAGEM: "A",
  COLETA_DOMICILIAR: "C",
  COLETA_SIMULTANEA: "CA",
};
