import { storage } from "../storage";

interface CorreiosToken {
  token: string;
  expiraEm: Date;
}

interface CorreiosEvento {
  codigo: string;
  tipo: string;
  dtHrCriado: string;
  descricao: string;
  detalhe?: string;
  unidade?: {
    tipo: string;
    endereco?: {
      cidade: string;
      uf: string;
    };
  };
  unidadeDestino?: {
    tipo: string;
    endereco?: {
      cidade: string;
      uf: string;
    };
  };
}

interface CorreiosObjeto {
  codObjeto: string;
  tipoPostal?: {
    sigla: string;
    descricao: string;
  };
  dtPrevista?: string;
  eventos: CorreiosEvento[];
}

interface RastreioResult {
  codigo: string;
  servico: string;
  previsaoEntrega?: string;
  eventos: {
    data: string;
    hora: string;
    local: string;
    status: string;
    detalhes?: string;
  }[];
}

let cachedToken: CorreiosToken | null = null;

const CORREIOS_API_BASE = "https://api.correios.com.br";

async function getToken(): Promise<string> {
  const apiKey = process.env.CORREIOS_API_KEY;
  if (apiKey) {
    return apiKey;
  }

  if (cachedToken && new Date(cachedToken.expiraEm) > new Date()) {
    return cachedToken.token;
  }

  const username = process.env.CORREIOS_USERNAME;
  const password = process.env.CORREIOS_PASSWORD;
  const cartaoPostagem = process.env.CORREIOS_CARTAO_POSTAGEM;

  if (!username || !password || !cartaoPostagem) {
    throw new Error("Credenciais dos Correios incompletas. Configure CORREIOS_API_KEY ou CORREIOS_USERNAME, CORREIOS_PASSWORD e CORREIOS_CARTAO_POSTAGEM.");
  }

  const basicAuth = Buffer.from(`${username}:${password}`).toString("base64");

  try {
    const response = await fetch(`${CORREIOS_API_BASE}/token/v1/autentica/cartaopostagem`, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${basicAuth}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        numero: cartaoPostagem,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      await logIntegration("correios", "/token/v1/autentica/cartaopostagem", { action: "authenticate" }, { error: errorText, status: response.status }, response.status);
      throw new Error(`Falha na autenticação: ${response.status}`);
    }

    const data = await response.json();
    
    cachedToken = {
      token: data.token,
      expiraEm: new Date(data.expiraEm),
    };

    await logIntegration("correios", "/token/v1/autentica/cartaopostagem", { action: "authenticate" }, { success: true, expiraEm: data.expiraEm }, 200);

    return cachedToken.token;
  } catch (error: any) {
    if (!error.message.includes("Credenciais")) {
      await logIntegration("correios", "/token/v1/autentica/cartaopostagem", { action: "authenticate" }, { error: error.message }, 0);
    }
    throw error;
  }
}

export class CorreiosError extends Error {
  public statusCode: number;
  public isClientError: boolean;
  
  constructor(message: string, statusCode: number, isClientError: boolean = true) {
    super(message);
    this.statusCode = statusCode;
    this.isClientError = isClientError;
  }
}

export async function rastrearObjeto(codigo: string): Promise<RastreioResult> {
  const codigoNormalizado = codigo.toUpperCase().replace(/[^A-Z0-9]/g, "");
  
  if (!/^[A-Z]{2}\d{9}[A-Z]{2}$/.test(codigoNormalizado)) {
    throw new CorreiosError("Código de rastreio inválido. Formato esperado: AA123456789BR", 400, true);
  }

  let token: string;
  try {
    token = await getToken();
  } catch (error: any) {
    if (error.message.includes("incompletas")) {
      throw new CorreiosError(error.message, 503, false);
    }
    throw new CorreiosError("Falha ao autenticar com os Correios", 503, false);
  }

  try {
    const url = `${CORREIOS_API_BASE}/srorastro/v1/objetos/${codigoNormalizado}?resultado=T`;
    console.log(`[Correios] Rastreando objeto: ${codigoNormalizado}`);
    
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json",
        "Accept-Language": "pt-BR",
      },
    });

    console.log(`[Correios] Response status: ${response.status}`);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.log(`[Correios] Response error: ${errorText}`);
      await logIntegration("correios", `/srorastro/v1/objetos/${codigoNormalizado}`, { action: "rastrear" }, { status: response.status, error: errorText.substring(0, 200) }, response.status);
      
      if (response.status === 401) {
        cachedToken = null;
        throw new CorreiosError("Token expirado ou inválido. Verifique a chave de API.", 401, true);
      }
      if (response.status === 403) {
        throw new CorreiosError("Objeto não pertence ao seu contrato. Desde 2025, só é possível rastrear objetos postados pelo seu contrato.", 403, true);
      }
      if (response.status === 404) {
        throw new CorreiosError("Objeto não encontrado ou sem eventos de rastreamento.", 404, true);
      }
      if (response.status === 400) {
        throw new CorreiosError("Código de rastreio inválido ou objeto não encontrado.", 400, true);
      }
      if (response.status >= 500) {
        throw new CorreiosError("Serviço dos Correios temporariamente indisponível.", 502, false);
      }
      throw new CorreiosError(`Erro ao rastrear objeto: ${response.status}`, response.status, response.status < 500);
    }

    const responseData = await response.json();
    
    // A API retorna um array de objetos
    const data: CorreiosObjeto = responseData.objetos?.[0];
    
    if (!data) {
      throw new CorreiosError("Objeto não encontrado ou sem eventos de rastreamento.", 404, true);
    }
    
    await logIntegration("correios", `/srorastro/v1/objetos/${codigoNormalizado}`, { action: "rastrear" }, { eventos: data.eventos?.length || 0 }, 200);

    const eventos = (data.eventos || []).map((evento: CorreiosEvento) => {
      const dt = new Date(evento.dtHrCriado);
      const cidade = evento.unidade?.endereco?.cidade || "";
      const uf = evento.unidade?.endereco?.uf || "";
      const local = cidade && uf ? `${cidade}/${uf}` : evento.unidade?.tipo || "Correios";
      
      let detalhes = evento.detalhe || "";
      if (!detalhes && evento.unidadeDestino?.endereco) {
        detalhes = `Para ${evento.unidadeDestino.endereco.cidade}/${evento.unidadeDestino.endereco.uf}`;
      }

      return {
        data: dt.toLocaleDateString("pt-BR"),
        hora: dt.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        local,
        status: evento.descricao,
        detalhes: detalhes || undefined,
      };
    });

    // Formatar data de previsão se existir
    let previsaoFormatada: string | undefined;
    if (data.dtPrevista) {
      const dt = new Date(data.dtPrevista);
      previsaoFormatada = dt.toLocaleDateString("pt-BR");
    }

    return {
      codigo: data.codObjeto,
      servico: data.tipoPostal?.descricao || "Correios",
      previsaoEntrega: previsaoFormatada,
      eventos,
    };
  } catch (error: any) {
    if (error instanceof CorreiosError) {
      throw error;
    }
    console.error("[Correios] Erro inesperado:", error.message);
    await logIntegration("correios", `/srorastro/v1/objetos/${codigoNormalizado}`, { action: "rastrear" }, { error: "fetch_error" }, 0);
    throw new CorreiosError("Erro de conexão com os Correios. Tente novamente.", 502, false);
  }
}

async function logIntegration(tipoApi: string, endpoint: string, requestData: any, responseData: any, statusCode: number) {
  try {
    await storage.addIntegrationLog({
      tipoApi,
      endpoint,
      requestData,
      responseData,
      statusCode,
    });
  } catch (e) {
    console.error("Erro ao salvar log de integração:", e);
  }
}

export function getIntegrationStatus(): { configured: boolean; tokenValid: boolean; expiraEm?: string; mode?: string } {
  const hasApiKey = !!process.env.CORREIOS_API_KEY;
  const hasBasicAuth = !!(
    process.env.CORREIOS_USERNAME && 
    process.env.CORREIOS_PASSWORD && 
    process.env.CORREIOS_CARTAO_POSTAGEM
  );
  const tokenValid = hasApiKey || !!(cachedToken && new Date(cachedToken.expiraEm) > new Date());
  
  return {
    configured: hasApiKey || hasBasicAuth,
    tokenValid,
    expiraEm: cachedToken?.expiraEm?.toISOString(),
    mode: hasApiKey ? "api_key" : (hasBasicAuth ? "basic_auth" : undefined),
  };
}
