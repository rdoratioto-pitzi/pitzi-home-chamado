# RenovLog - Plataforma de Controle Logístico

## Visão Geral
Plataforma completa de controle logístico com gestão de operadores, cotação de frete, rastreamento e emissão de CT-e.

## Dados da Empresa
- **Razão Social**: RENOV SOLUCOES E SERVICOS LTDA
- **CNPJ**: 50.955.750/0002-76
- **Endereço**: R LUIGI GALVANI, 200 CONJ 11, CEP 04.575-020, CIDADE MONCOES, SAO PAULO - SP
- **Email**: MATHEUS@RENOVSMART.COM.BR
- **Telefone**: (51) 3543-8777

## Alterações Recentes
- **2026-01-26**: Implementada integração completa com Logística Reversa dos Correios (SOAP)
- **2026-01-26**: Criada página Logística Reversa com formulário de coleta, upload em massa e acompanhamento
- **2026-01-20**: Implementada integração com API Correios (Rastro) para rastreamento de encomendas
- **2026-01-19**: Renomeado de LogiTech para RenovLog
- **2026-01-19**: Adicionados novos KPIs no Dashboard (Status Dispositivos, Custo Unitário Médio de Frete)
- **2026-01-19**: Criada página Romaneios para consulta de status de cargas
- **2026-01-19**: Criada página APIs Log com documentação de endpoints e integrações

## Integrações Externas

### Correios - API Rastro (SRO)
- **Status**: Ativo e funcionando
- **Funcionalidade**: Rastreamento de encomendas em tempo real
- **Endpoint Correios**: `/srorastro/v1/objetos/{codigo}?resultado=T`
- **Autenticação**: Bearer token via CORREIOS_API_KEY (chave de acesso CWS)
- **Headers obrigatórios**: Accept-Language: pt-BR
- **Credenciais configuradas**:
  - CORREIOS_API_KEY - Chave de acesso CWS (token Bearer)
- **Restrição 2025+**: Apenas objetos do próprio contrato podem ser rastreados
- **Endpoints implementados**:
  - GET /api/integrations/correios/status
  - GET /api/integrations/correios/rastro/:codigo
  - GET /api/integrations/logs

### Correios - Logística Reversa (SOAP)
- **Status**: Modo Simulação (API requer novo modelo de autenticação dos Correios)
- **Funcionalidade**: Solicitação e acompanhamento de coletas reversas
- **WSDL Produção**: https://apps.correios.com.br/logisticaReversaWS/logisticaReversaService/logisticaReversaWS?wsdl
- **WSDL Homologação**: https://apphom.correios.com.br/logisticaReversaWS/logisticaReversaService/logisticaReversaWS?wsdl

#### Problema Atual: Erro 401 Unauthorized
O erro 401 indica que as credenciais de acesso à API estão inválidas ou expiradas.

#### Como Resolver - Passo a Passo:

**1. Acesse o Portal Meu Correios**
   - URL: https://meucorreios.correios.com.br/
   - Faça login com a conta PJ vinculada ao seu contrato
   - Se não tem conta, crie uma usando os mesmos dados do contrato (CNPJ, nome, endereço)

**2. Acesse o Portal CWS (Correios Web Services)**
   - URL: https://cws.correios.com.br/
   - Faça login com as credenciais do Meu Correios
   - No menu lateral, clique em "Gestão de acesso a APIs"

**3. Gere o Código de Acesso**
   - Clique em "Gerar Código de Acesso"
   - IMPORTANTE: Este código expira em 24 horas!
   - Anote o código gerado

**4. Atualize as Credenciais no Sistema**
   - `CORREIOS_LR_USUARIO`: Seu usuário do Meu Correios (geralmente o CPF/CNPJ)
   - `CORREIOS_LR_SENHA`: O Código de Acesso gerado no passo 3 (NÃO é a senha do Meu Correios!)
   - `CORREIOS_LR_COD_ADMINISTRATIVO`: Código administrativo do seu contrato
   - `CORREIOS_CARTAO_POSTAGEM`: Número do cartão de postagem

**5. Verifique a Liberação do Componente LR**
   - O componente "Logística Reversa" deve estar habilitado no seu contrato
   - Caso não esteja, entre em contato com seu gestor comercial dos Correios

#### Credenciais Configuradas:
- CORREIOS_LR_USUARIO - Usuário Meu Correios (CPF/CNPJ)
- CORREIOS_LR_SENHA - Código de Acesso CWS (válido por 24h)
- CORREIOS_LR_COD_ADMINISTRATIVO - Código administrativo do contrato
- CORREIOS_CARTAO_POSTAGEM - Cartão de postagem

#### Modo Simulação:
- Ativado automaticamente quando WSDL falha ou credenciais inválidas
- Gera números de pedido com prefixo "SIM" para demonstração
- Pedidos são salvos no banco de dados normalmente

#### Links Úteis:
- Portal CWS: https://cws.correios.com.br/
- Documentação APIs: https://www.correios.com.br/atendimento/developers
- Manual LR: https://www.correios.com.br/atendimento/developers/arquivos/manual-de-implementacao-do-web-service-logistica-reversa.pdf
- **Serviços disponíveis**:
  - PAC Reversa (41076), SEDEX Reversa (40010), SEDEX 10 (40215), SEDEX 12 (40290)
- **Tipos de coleta**:
  - A (Autorização de Postagem), C (Coleta Domiciliar), CA (Coleta Simultânea)
- **Endpoints implementados**:
  - GET /api/logistica-reversa/status
  - GET /api/logistica-reversa/pedidos
  - GET /api/logistica-reversa/pedido/:id
  - GET /api/logistica-reversa/stats
  - GET /api/logistica-reversa/servicos
  - POST /api/logistica-reversa/solicitar
  - POST /api/logistica-reversa/solicitar-massa
  - POST /api/logistica-reversa/cancelar/:id
  - POST /api/logistica-reversa/revalidar/:id
  - POST /api/logistica-reversa/atualizar-status/:id
- **Tabelas do banco**:
  - logistica_reversa_pedidos - Pedidos de coleta reversa
  - logistica_reversa_eventos - Histórico de eventos dos pedidos

## Estrutura do Projeto

### Frontend (client/src/)
- **pages/**: Páginas da aplicação
  - dashboard.tsx - Dashboard com KPIs e estatísticas
  - auth.tsx - Tela de login
  - operators.tsx - Gestão de operadores logísticos
  - requests.tsx - Solicitações de coleta
  - simulation.tsx - Simulação de frete
  - cte.tsx - Emissões de CT-e
  - romaneios.tsx - Consulta de romaneios de carga
  - logistica-reversa.tsx - Logística Reversa (coleta individual, massa, acompanhamento)
  - apis.tsx - Documentação de APIs e integrações (inclui Correios)
- **components/**: Componentes reutilizáveis
  - layout-shell.tsx - Layout principal com sidebar
  - ui/ - Componentes Shadcn UI
- **hooks/**: Hooks customizados
  - use-auth.ts - Autenticação
  - use-logistics.ts - Dados logísticos

### Backend (server/)
- routes.ts - Rotas da API
- storage.ts - Camada de dados
- auth.ts - Autenticação com Passport.js
- db.ts - Conexão com PostgreSQL
- services/correios.ts - Serviço de integração com Correios (Rastreamento REST)
- services/correios-logistica-reversa.ts - Serviço de Logística Reversa (SOAP)

### Compartilhado (shared/)
- schema.ts - Schemas do banco de dados (Drizzle)
- routes.ts - Contratos da API

## Credenciais de Teste
- Admin: admin@logistica.com / admin123
- Cliente: cliente@empresa.com / cliente123

## Preferências do Usuário
- Idioma: Português Brasileiro
- Moeda: BRL (R$)
- Formato de data: DD/MM/YYYY

## Tecnologias
- React + Vite (Frontend)
- Express (Backend)
- PostgreSQL + Drizzle ORM (Banco de dados)
- Passport.js (Autenticação)
- Shadcn UI + Tailwind CSS (Estilização)
- Recharts (Gráficos)
