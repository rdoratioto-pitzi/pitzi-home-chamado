import { z } from 'zod';
import { 
  insertUserSchema, users, 
  insertOperatorSchema, logisticOperators,
  insertCoverageSchema, operatorCoverage,
  insertPriceSchema, priceTables,
  insertRequestSchema, collectionRequests,
  insertCteSchema, cteEmissions,
  insertTrackingSchema, trackingStatus,
  integrationLogs
} from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login',
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/users',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  operators: {
    list: {
      method: 'GET' as const,
      path: '/api/operators',
      responses: {
        200: z.array(z.custom<typeof logisticOperators.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/operators/:id',
      responses: {
        200: z.custom<typeof logisticOperators.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/operators',
      input: insertOperatorSchema,
      responses: {
        201: z.custom<typeof logisticOperators.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/operators/:id',
      input: insertOperatorSchema.partial(),
      responses: {
        200: z.custom<typeof logisticOperators.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  coverage: {
    list: {
      method: 'GET' as const,
      path: '/api/operators/:operatorId/coverage',
      responses: {
        200: z.array(z.custom<typeof operatorCoverage.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/operators/:operatorId/coverage',
      input: insertCoverageSchema.omit({ operatorId: true }),
      responses: {
        201: z.custom<typeof operatorCoverage.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  prices: {
    list: {
      method: 'GET' as const,
      path: '/api/operators/:operatorId/prices',
      responses: {
        200: z.array(z.custom<typeof priceTables.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/operators/:operatorId/prices',
      input: insertPriceSchema.omit({ operatorId: true }),
      responses: {
        201: z.custom<typeof priceTables.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  requests: {
    list: {
      method: 'GET' as const,
      path: '/api/requests',
      responses: {
        200: z.array(z.any()), // RequestWithDetails - z.custom is tricky with joined types, using z.any for complex responses
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/requests/:id',
      responses: {
        200: z.any(), // RequestWithDetails
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/requests',
      input: insertRequestSchema,
      responses: {
        201: z.custom<typeof collectionRequests.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    simulate: {
      method: 'POST' as const,
      path: '/api/requests/simulate',
      input: z.object({
        origem: z.string(),
        destino: z.string(),
        peso: z.number(),
        cubagem: z.number(),
      }),
      responses: {
        200: z.array(z.object({
          operatorId: z.number(),
          operatorName: z.string(),
          price: z.number(),
          deadline: z.number(),
          score: z.number(),
        })),
      },
    },
  },
  cte: {
    list: {
      method: 'GET' as const,
      path: '/api/cte',
      responses: {
        200: z.array(z.custom<typeof cteEmissions.$inferSelect>()),
      },
    },
  },
  tracking: {
    history: {
      method: 'GET' as const,
      path: '/api/requests/:requestId/tracking',
      responses: {
        200: z.array(z.custom<typeof trackingStatus.$inferSelect>()),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/requests/:requestId/tracking',
      input: insertTrackingSchema.omit({ requestId: true }),
      responses: {
        201: z.custom<typeof trackingStatus.$inferSelect>(),
      },
    },
  },
  dashboard: {
    stats: {
      method: 'GET' as const,
      path: '/api/dashboard/stats',
      responses: {
        200: z.object({
          totalRequests: z.number(),
          totalValue: z.number(),
          onTimeRate: z.number(),
          savings: z.number(),
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
