import { pgTable, text, serial, integer, boolean, timestamp, numeric, jsonb, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("viewer"), // admin, operator, viewer, client
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const logisticOperators = pgTable("logistic_operators", {
  id: serial("id").primaryKey(),
  razaoSocial: text("razao_social").notNull(),
  cnpj: text("cnpj").notNull().unique(),
  contato: text("contato"),
  email: text("email").notNull(),
  telefone: text("telefone"),
  ativo: boolean("ativo").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const operatorCoverage = pgTable("operator_coverage", {
  id: serial("id").primaryKey(),
  operatorId: integer("operator_id").notNull(),
  uf: text("uf").notNull(),
  prazoDias: integer("prazo_dias").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const priceTables = pgTable("price_tables", {
  id: serial("id").primaryKey(),
  operatorId: integer("operator_id").notNull(),
  pesoMin: numeric("peso_min").notNull(),
  pesoMax: numeric("peso_max").notNull(),
  valorKg: numeric("valor_kg").notNull(),
  cubagemMax: numeric("cubagem_max"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const collectionRequests = pgTable("collection_requests", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id"), // Can be null if created by admin without specific client user
  origem: text("origem").notNull(),
  destino: text("destino").notNull(), // UF or City
  peso: numeric("peso").notNull(),
  cubagem: numeric("cubagem").notNull(),
  status: text("status").notNull().default("pending"), // pending, quoted, approved, collected, delivered, cancelled
  recommendedOperatorId: integer("recommended_operator_id"),
  valorEstimado: numeric("valor_estimado"),
  prazoEstimado: integer("prazo_estimado"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cteEmissions = pgTable("cte_emissions", {
  id: serial("id").primaryKey(),
  numeroCte: text("numero_cte"),
  chaveAcesso: text("chave_acesso"),
  operatorId: integer("operator_id"),
  requestId: integer("request_id"),
  valor: numeric("valor"),
  statusSefaz: text("status_sefaz").default("pending"), // pending, authorized, cancelled, error
  dataEmissao: timestamp("data_emissao"),
  xmlPath: text("xml_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trackingStatus = pgTable("tracking_status", {
  id: serial("id").primaryKey(),
  requestId: integer("request_id").notNull(),
  status: text("status").notNull(),
  dataHora: timestamp("data_hora").defaultNow(),
  localizacao: text("localizacao"),
  observacao: text("observacao"),
});

export const integrationLogs = pgTable("integration_logs", {
  id: serial("id").primaryKey(),
  tipoApi: text("tipo_api").notNull(), // correios, sefaz, operator, correios_lr
  endpoint: text("endpoint"),
  requestData: jsonb("request_data"),
  responseData: jsonb("response_data"),
  statusCode: integer("status_code"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const logisticaReversaPedidos = pgTable("logistica_reversa_pedidos", {
  id: serial("id").primaryKey(),
  numeroPedido: text("numero_pedido"),
  numeroEtiqueta: text("numero_etiqueta"),
  tipo: text("tipo").notNull(), // A = Autorização, C = Coleta, CA = Coleta Simultânea
  codigoServico: text("codigo_servico").notNull(),
  status: text("status").notNull().default("solicitado"), // solicitado, aguardando_postagem, coletado, em_transito, entregue, cancelado
  idCliente: text("id_cliente"),
  prazo: text("prazo"),
  remetenteNome: text("remetente_nome"),
  remetenteCep: text("remetente_cep"),
  remetenteEndereco: text("remetente_endereco"),
  remetenteCidade: text("remetente_cidade"),
  remetenteUf: text("remetente_uf"),
  remetenteEmail: text("remetente_email"),
  remetenteTelefone: text("remetente_telefone"),
  destinatarioNome: text("destinatario_nome"),
  destinatarioCep: text("destinatario_cep"),
  destinatarioEndereco: text("destinatario_endereco"),
  destinatarioCidade: text("destinatario_cidade"),
  destinatarioUf: text("destinatario_uf"),
  observacao: text("observacao"),
  dataSolicitacao: timestamp("data_solicitacao").defaultNow(),
  dataUltimaAtualizacao: timestamp("data_ultima_atualizacao"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const logisticaReversaEventos = pgTable("logistica_reversa_eventos", {
  id: serial("id").primaryKey(),
  pedidoId: integer("pedido_id").notNull(),
  status: text("status").notNull(),
  descricao: text("descricao"),
  dataEvento: timestamp("data_evento").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  requests: many(collectionRequests),
}));

export const operatorsRelations = relations(logisticOperators, ({ many }) => ({
  coverages: many(operatorCoverage),
  prices: many(priceTables),
  requests: many(collectionRequests),
  ctes: many(cteEmissions),
}));

export const coverageRelations = relations(operatorCoverage, ({ one }) => ({
  operator: one(logisticOperators, {
    fields: [operatorCoverage.operatorId],
    references: [logisticOperators.id],
  }),
}));

export const priceRelations = relations(priceTables, ({ one }) => ({
  operator: one(logisticOperators, {
    fields: [priceTables.operatorId],
    references: [logisticOperators.id],
  }),
}));

export const requestRelations = relations(collectionRequests, ({ one, many }) => ({
  client: one(users, {
    fields: [collectionRequests.clientId],
    references: [users.id],
  }),
  operator: one(logisticOperators, {
    fields: [collectionRequests.recommendedOperatorId],
    references: [logisticOperators.id],
  }),
  tracking: many(trackingStatus),
  cte: one(cteEmissions, { // Assuming 1-1 for simplicity, though could be many
    fields: [collectionRequests.id],
    references: [cteEmissions.requestId],
  }),
}));

export const cteRelations = relations(cteEmissions, ({ one }) => ({
  operator: one(logisticOperators, {
    fields: [cteEmissions.operatorId],
    references: [logisticOperators.id],
  }),
  request: one(collectionRequests, {
    fields: [cteEmissions.requestId],
    references: [collectionRequests.id],
  }),
}));

export const trackingRelations = relations(trackingStatus, ({ one }) => ({
  request: one(collectionRequests, {
    fields: [trackingStatus.requestId],
    references: [collectionRequests.id],
  }),
}));

export const logisticaReversaPedidosRelations = relations(logisticaReversaPedidos, ({ many }) => ({
  eventos: many(logisticaReversaEventos),
}));

export const logisticaReversaEventosRelations = relations(logisticaReversaEventos, ({ one }) => ({
  pedido: one(logisticaReversaPedidos, {
    fields: [logisticaReversaEventos.pedidoId],
    references: [logisticaReversaPedidos.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export const insertOperatorSchema = createInsertSchema(logisticOperators).omit({ id: true, createdAt: true });
export const insertCoverageSchema = createInsertSchema(operatorCoverage).omit({ id: true, createdAt: true });
export const insertPriceSchema = createInsertSchema(priceTables).omit({ id: true, createdAt: true });
export const insertRequestSchema = createInsertSchema(collectionRequests).omit({ id: true, createdAt: true, status: true, recommendedOperatorId: true, valorEstimado: true, prazoEstimado: true });
export const insertCteSchema = createInsertSchema(cteEmissions).omit({ id: true, createdAt: true });
export const insertTrackingSchema = createInsertSchema(trackingStatus).omit({ id: true, dataHora: true });
export const insertLogisticaReversaPedidoSchema = createInsertSchema(logisticaReversaPedidos).omit({ id: true, createdAt: true, dataSolicitacao: true, dataUltimaAtualizacao: true });
export const insertLogisticaReversaEventoSchema = createInsertSchema(logisticaReversaEventos).omit({ id: true, createdAt: true, dataEvento: true });

// === TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type LogisticOperator = typeof logisticOperators.$inferSelect;
export type InsertOperator = z.infer<typeof insertOperatorSchema>;

export type OperatorCoverage = typeof operatorCoverage.$inferSelect;
export type InsertCoverage = z.infer<typeof insertCoverageSchema>;

export type PriceTable = typeof priceTables.$inferSelect;
export type InsertPrice = z.infer<typeof insertPriceSchema>;

export type CollectionRequest = typeof collectionRequests.$inferSelect;
export type InsertRequest = z.infer<typeof insertRequestSchema>;

export type CteEmission = typeof cteEmissions.$inferSelect;
export type InsertCte = z.infer<typeof insertCteSchema>;

export type TrackingStatus = typeof trackingStatus.$inferSelect;
export type InsertTracking = z.infer<typeof insertTrackingSchema>;

export type IntegrationLog = typeof integrationLogs.$inferSelect;

// Helper Types for Frontend
export type RequestWithDetails = CollectionRequest & {
  operator?: LogisticOperator | null;
  client?: User | null;
  tracking?: TrackingStatus[];
  cte?: CteEmission | null;
};

export type SimulationResult = {
  operatorId: number;
  operatorName: string;
  price: number;
  deadline: number;
  score: number;
};

export type LogisticaReversaPedido = typeof logisticaReversaPedidos.$inferSelect;
export type InsertLogisticaReversaPedido = z.infer<typeof insertLogisticaReversaPedidoSchema>;

export type LogisticaReversaEvento = typeof logisticaReversaEventos.$inferSelect;
export type InsertLogisticaReversaEvento = z.infer<typeof insertLogisticaReversaEventoSchema>;

export type LogisticaReversaPedidoWithEventos = LogisticaReversaPedido & {
  eventos?: LogisticaReversaEvento[];
};
